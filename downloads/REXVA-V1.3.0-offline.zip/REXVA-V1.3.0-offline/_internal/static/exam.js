/* Rexx Hub - student exam screen.
   The server owns the clock: the deadline is fixed when the exam starts, every autosave
   returns the seconds left, and the server refuses answers after the deadline. */
(() => {
  const bootEl = document.getElementById('boot');
  const boot = JSON.parse(bootEl.textContent);
  const csrf = bootEl.dataset.csrf;
  const Q = boot.questions;
  const answers = Object.assign({}, boot.answers);       // question id (string) -> response
  const flagsKey = 'rexx-flags-' + boot.attemptId;
  let flags = new Set();
  try { flags = new Set(JSON.parse(localStorage.getItem(flagsKey) || '[]')); } catch (e) { /* ignore */ }

  const $ = id => document.getElementById(id);
  const card = $('qcard'), grid = $('pgrid'), timerEl = $('timer'), stateEl = $('savestate');
  let idx = 0;
  let endAt = performance.now() + boot.remaining * 1000;
  let submitting = false, finished = false;

  const post = (url, body) => fetch(url, {
    method: 'POST', credentials: 'same-origin', keepalive: true,
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf},
    body: JSON.stringify(body || {}),
  });

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };
  const answered = q => (answers[q.id] || '') !== '';

  /* ---------------- saving ---------------- */
  const pending = new Map();
  let flushing = false;
  const setState = (msg, bad) => { stateEl.textContent = msg; stateEl.classList.toggle('err', !!bad); };

  function queueSave(qid, value) {
    pending.set(String(qid), value);
    setState('Saving…');
    flush();
  }

  async function flush() {
    if (flushing) return;
    flushing = true;
    while (pending.size && !finished) {
      const [qid, value] = pending.entries().next().value;
      try {
        const r = await post(boot.urls.answer, {question_id: Number(qid), response: value});
        if (r.status === 409) {                        // clock ran out server side
          const j = await r.json();
          finished = true; window.location.href = j.redirect; return;
        }
        if (!r.ok) throw new Error('save failed');
        const j = await r.json();
        endAt = performance.now() + j.remaining * 1000; // re-sync with the server clock
        if (pending.get(qid) === value) pending.delete(qid);
        setState('Saved ✓');
      } catch (e) {
        setState('Offline - retrying…', true);
        flushing = false;
        setTimeout(flush, 2500);
        return;
      }
    }
    flushing = false;
  }

  /* ---------------- rendering ---------------- */
  function choose(q, key) {
    answers[q.id] = key;
    queueSave(q.id, key);
    render();
  }

  function render() {
    const q = Q[idx];
    card.replaceChildren();

    const meta = el('div', 'qmeta');
    meta.append(el('span', '', 'Question ' + (idx + 1) + ' of ' + Q.length),
                el('span', '', q.marks + (q.marks === 1 ? ' mark' : ' marks')));
    card.append(meta, el('div', 'qtext', q.text));
    if (q.image) { const im = el('img', 'qimg'); im.src = q.image; im.alt = 'Question diagram'; card.append(im); }

    if (q.type === 'short') {
      const input = el('input');
      input.type = 'text'; input.placeholder = 'Type your answer'; input.autocomplete = 'off';
      input.value = answers[q.id] || '';
      let t;
      input.addEventListener('input', () => {
        answers[q.id] = input.value;
        clearTimeout(t);
        t = setTimeout(() => queueSave(q.id, input.value), 600);
        paintPalette();
      });
      input.addEventListener('blur', () => { clearTimeout(t); if (input.value !== (boot.answers[q.id] || '') || pending.has(String(q.id))) queueSave(q.id, input.value); });
      card.append(input);
      setTimeout(() => input.focus(), 0);
    } else {
      q.options.forEach((o, i) => {
        const b = el('button', 'choice' + (answers[q.id] === o.key ? ' sel' : ''));
        b.type = 'button';
        const label = q.type === 'tf' ? o.text[0] : String.fromCharCode(65 + i);
        b.append(el('span', 'ltr', label), el('span', '', o.text));
        b.addEventListener('click', () => choose(q, o.key));
        card.append(b);
      });
    }

    const nav = el('div', 'qnav');
    const left = el('div', 'row'), right = el('div', 'row');
    const prev = el('button', 'btn', '← Previous'); prev.type = 'button'; prev.disabled = idx === 0;
    prev.addEventListener('click', () => go(idx - 1));
    const flag = el('button', 'btn', flags.has(q.id) ? 'Unmark' : 'Mark for review'); flag.type = 'button';
    flag.addEventListener('click', () => {
      flags.has(q.id) ? flags.delete(q.id) : flags.add(q.id);
      try { localStorage.setItem(flagsKey, JSON.stringify([...flags])); } catch (e) { /* ignore */ }
      render();
    });
    left.append(prev, flag);
    if (answered(q)) {
      const clear = el('button', 'btn', 'Clear answer'); clear.type = 'button';
      clear.addEventListener('click', () => { answers[q.id] = ''; queueSave(q.id, ''); render(); });
      left.append(clear);
    }
    if (idx < Q.length - 1) {
      const next = el('button', 'btn primary', 'Next →'); next.type = 'button';
      next.addEventListener('click', () => go(idx + 1));
      right.append(next);
    } else {
      const fin = el('button', 'btn dark', 'Finish & submit'); fin.type = 'button';
      fin.addEventListener('click', askSubmit);
      right.append(fin);
    }
    nav.append(left, right);
    card.append(nav);
    paintPalette();
  }

  function paintPalette() {
    if (!grid.children.length) {
      Q.forEach((q, i) => {
        const b = el('button', '', String(i + 1)); b.type = 'button';
        b.addEventListener('click', () => go(i));
        grid.append(b);
      });
    }
    Q.forEach((q, i) => {
      const b = grid.children[i];
      b.className = (answered(q) ? 'done ' : '') + (flags.has(q.id) ? 'flag ' : '') + (i === idx ? 'cur' : '');
    });
    $('count').textContent = '(' + Q.filter(answered).length + '/' + Q.length + ' answered)';
  }

  function go(i) { if (i >= 0 && i < Q.length) { idx = i; render(); window.scrollTo({top: 0}); } }

  /* ---------------- timer ---------------- */
  const pad = n => String(n).padStart(2, '0');
  function tick() {
    const left = Math.max(0, Math.ceil((endAt - performance.now()) / 1000));
    const h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
    timerEl.textContent = (h ? h + ':' : '') + pad(m) + ':' + pad(s);
    timerEl.classList.toggle('low', left <= 300 && left > 60);
    timerEl.classList.toggle('crit', left <= 60);
    if (left <= 0 && !submitting) submit(true);
  }
  setInterval(tick, 250);
  tick();

  /* ---------------- submit ---------------- */
  const modal = $('modal'), busy = $('busy');
  function askSubmit() {
    const un = Q.filter(q => !answered(q)).length;
    const fl = Q.filter(q => flags.has(q.id)).length;
    let txt = un ? 'You have ' + un + ' unanswered question' + (un > 1 ? 's' : '') + '.' : 'You have answered every question.';
    if (fl) txt += ' ' + fl + ' marked for review.';
    $('modal-text').textContent = txt + ' You cannot change your answers after submitting.';
    modal.hidden = false;
  }
  $('finish-top').addEventListener('click', askSubmit);
  $('finish-side').addEventListener('click', askSubmit);
  $('cancel-submit').addEventListener('click', () => { modal.hidden = true; });
  $('confirm-submit').addEventListener('click', () => submit(false));

  async function submit(auto) {
    if (submitting) return;
    submitting = true; modal.hidden = true; hideGate(); busy.hidden = false;
    $('busy-text').textContent = auto ? "Time is up - submitting your exam…" : 'Submitting your exam…';
    try {
      const r = await post(boot.urls.submit, {answers});
      const j = await r.json();
      finished = true;
      exitFS();
      window.location.href = j.redirect;
    } catch (e) {
      $('busy-text').textContent = 'No connection - retrying…';
      submitting = false;
      setTimeout(() => submit(true), 2000);               // keep trying until the server hears us
    }
  }

  /* ---------------- guards: fullscreen + 3 warnings ----------------
     Leaving fullscreen, switching tab, or switching to another window = 1 warning.
     The 3rd warning ends the exam: strict exams are submitted by the server and the account is locked
     (the server does that on its first "flag" call, so in strict mode we only call it on the 3rd);
     normal exams are simply submitted. The count survives a page reload. */
  const MAX_WARN = 3;
  const strikeKey = 'rexx-strikes-' + boot.attemptId;
  let strikes = 0;
  try { strikes = Math.min(MAX_WARN, parseInt(localStorage.getItem(strikeKey) || '0', 10) || 0); } catch (e) { /* ignore */ }
  const saveStrikes = () => { try { localStorage.setItem(strikeKey, String(strikes)); } catch (e) { /* ignore */ } };

  const root = document.documentElement;
  const canFS = !!(root.requestFullscreen || root.webkitRequestFullscreen);   // iPhones have no fullscreen API
  const inFS = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
  const enterFS = () => Promise.resolve(root.requestFullscreen ? root.requestFullscreen() : root.webkitRequestFullscreen());
  function exitFS() {
    try { if (inFS()) (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) { /* ignore */ }
  }

  const gate = $('fs-gate'), gateTitle = $('gate-title'), gateText = $('gate-text'),
        gateBtn = $('gate-btn'), gateDots = $('gate-dots');
  let gateOpen = false, ending = false, graceUntil = 0, strictNote = null;
  const penalty = boot.strict ? 'your exam is submitted and your account is locked' : 'your exam is submitted automatically';

  function paintStrikes() {
    gateDots.replaceChildren();
    for (let i = 0; i < MAX_WARN; i++) gateDots.append(el('i', i < strikes ? 'on' : ''));
    if (strictNote) strictNote.textContent = 'STRICT MODE · Warnings used: ' + strikes + ' of ' + MAX_WARN +
      ' · If you leave fullscreen or this page 3 times, your exam is submitted and your account is locked.';
  }
  function hideGate() { gateOpen = false; gate.hidden = true; }
  function showGate(mode, reason) {
    gateOpen = true;
    paintStrikes();
    if (mode === 'start') {
      gateTitle.textContent = canFS ? 'This exam runs in fullscreen' : 'Before you begin';
      gateText.textContent = 'If you leave fullscreen, switch tab or open another window you get a warning. After ' +
        MAX_WARN + ' warnings ' + penalty + '.' + (strikes ? ' You have already used ' + strikes + ' warning' + (strikes > 1 ? 's' : '') + '.' : '');
      gateBtn.textContent = canFS ? 'Enter fullscreen and begin' : 'Begin';
    } else {
      const left = MAX_WARN - strikes;
      gateTitle.textContent = 'Warning ' + strikes + ' of ' + MAX_WARN;
      gateText.textContent = reason + ' ' + (left === 1
        ? 'This is your LAST warning. If it happens again, ' + penalty + '.'
        : left + ' warnings left. After the ' + MAX_WARN + 'rd, ' + penalty + '.');
      gateBtn.textContent = canFS ? 'Return to fullscreen and continue' : 'Continue';
    }
    gate.hidden = false;
    gateBtn.focus();
  }
  gateBtn.addEventListener('click', () => {
    const done = () => { graceUntil = Date.now() + 700; hideGate(); };
    if (!canFS || inFS()) { done(); return; }
    enterFS().then(done).catch(() => {
      gateText.textContent = 'The browser blocked fullscreen. Press F11 or allow fullscreen for this site, then press the button again.';
    });
  });

  function violation(reason) {
    if (finished || submitting || ending || gateOpen || Date.now() < graceUntil) return;
    strikes++; saveStrikes();
    if (strikes >= MAX_WARN) { paintStrikes(); endForViolations(); return; }
    if (!boot.strict) post(boot.urls.flag, {}).catch(() => {});   // normal exams: teacher sees every leave
    showGate('warn', reason);
  }

  async function endForViolations() {
    ending = true; modal.hidden = true; hideGate(); busy.hidden = false;
    $('busy-text').textContent = 'Warning limit reached - ending your exam…';
    let locked = false;
    for (let i = 0; i < 6; i++) {
      try { const r = await post(boot.urls.flag, {}); const j = await r.json(); locked = !!(j && j.locked); break; }
      catch (e) { await new Promise(r => setTimeout(r, 1500)); }
    }
    if (locked) { finished = true; exitFS(); window.location.replace('/login'); return; }
    ending = false;
    submit(true);                                    // not locked (normal exam): just submit it
  }

  window.addEventListener('beforeunload', e => { if (!finished) { e.preventDefault(); e.returnValue = ''; } });
  document.addEventListener('visibilitychange', () => { if (document.hidden) violation('You switched to another tab or minimised the browser.'); });
  window.addEventListener('blur', () => setTimeout(() => {
    if (!document.hasFocus() && !document.hidden) violation('You switched to another window or application.');
  }, 400));
  const onFsChange = () => { if (canFS && !inFS()) violation('You left fullscreen.'); };
  document.addEventListener('fullscreenchange', onFsChange);
  document.addEventListener('webkitfullscreenchange', onFsChange);

  if (boot.strict) {   // the only notice on top of the exam screen
    strictNote = document.createElement('div');
    strictNote.style.cssText = 'background:#7f1d1d;color:#fff;padding:8px 12px;text-align:center;font-weight:700;font-size:.85rem';
    document.body.prepend(strictNote);
  }
  paintStrikes();
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('keydown', e => {
    if (gateOpen || e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || modal.hidden === false) return;
    const q = Q[idx];
    if (e.key === 'ArrowRight') go(idx + 1);
    else if (e.key === 'ArrowLeft') go(idx - 1);
    else if (q.type === 'mcq') {
      const i = 'abcde'.indexOf(e.key.toLowerCase());
      if (i >= 0 && q.options[i]) choose(q, q.options[i].key);
    } else if (q.type === 'tf') {
      if (e.key.toLowerCase() === 't') choose(q, 'TRUE');
      if (e.key.toLowerCase() === 'f') choose(q, 'FALSE');
    }
  });

  render();
  if (strikes >= MAX_WARN) endForViolations();        // limit already reached before a reload
  else if (canFS) showGate('start');                  // fullscreen needs a click, so ask for one first
})();
