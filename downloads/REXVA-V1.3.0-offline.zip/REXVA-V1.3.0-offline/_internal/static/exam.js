/* Rexx Hub - student exam screen.
   The server owns the clock: the deadline is fixed when the exam starts, every autosave
   returns the seconds left, and the server refuses answers after the deadline. */
(() => {
  const bootEl = document.getElementById('boot');
  const boot = JSON.parse(bootEl.textContent);
  const csrf = bootEl.dataset.csrf;
  const Q = boot.questions;
  const answers = Object.assign({}, boot.answers);       // question id (string) -> response
  const flagsKey = 'rexx-flags-' + boot.attemptId;
  let flags = new Set();
  try { flags = new Set(JSON.parse(localStorage.getItem(flagsKey) || '[]')); } catch (e) { /* ignore */ }

  const $ = id => document.getElementById(id);
  const card = $('qcard'), grid = $('pgrid'), timerEl = $('timer'), stateEl = $('savestate');
  let idx = 0;
  let endAt = performance.now() + boot.remaining * 1000;
  let submitting = false, finished = false;

  const post = (url, body) => fetch(url, {
    method: 'POST', credentials: 'same-origin', keepalive: true,
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf},
    body: JSON.stringify(body || {}),
  });

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };
  const answered = q => (answers[q.id] || '') !== '';

  /* ---------------- saving ---------------- */
  const pending = new Map();
  let flushing = false;
  const setState = (msg, bad) => { stateEl.textContent = msg; stateEl.classList.toggle('err', !!bad); };

  function queueSave(qid, value) {
    pending.set(String(qid), value);
    setState('Saving…');
    flush();
  }

  async function flush() {
    if (flushing) return;
    flushing = true;
    while (pending.size && !finished) {
      const [qid, value] = pending.entries().next().value;
      try {
        const r = await post(boot.urls.answer, {question_id: Number(qid), response: value});
        if (r.status === 409) {                        // clock ran out server side
          const j = await r.json();
          finished = true; window.location.href = j.redirect; return;
        }
        if (!r.ok) throw new Error('save failed');
        const j = await r.json();
        endAt = performance.now() + j.remaining * 1000; // re-sync with the server clock
        if (pending.get(qid) === value) pending.delete(qid);
        setState('Saved ✓');
      } catch (e) {
        setState('Offline - retrying…', true);
        flushing = false;
        setTimeout(flush, 2500);
        return;
      }
    }
    flushing = false;
  }

  /* ---------------- rendering ---------------- */
  function choose(q, key) {
    answers[q.id] = key;
    queueSave(q.id, key);
    render();
  }

  function render() {
    const q = Q[idx];
    card.replaceChildren();

    const meta = el('div', 'qmeta');
    meta.append(el('span', '', 'Question ' + (idx + 1) + ' of ' + Q.length),
                el('span', '', q.marks + (q.marks === 1 ? ' mark' : ' marks')));
    card.append(meta, el('div', 'qtext', q.text));
    if (q.image) { const im = el('img', 'qimg'); im.src = q.image; im.alt = 'Question diagram'; card.append(im); }

    if (q.type === 'short') {
      const input = el('input');
      input.type = 'text'; input.placeholder = 'Type your answer'; input.autocomplete = 'off';
      input.value = answers[q.id] || '';
      let t;
      input.addEventListener('input', () => {
        answers[q.id] = input.value;
        clearTimeout(t);
        t = setTimeout(() => queueSave(q.id, input.value), 600);
        paintPalette();
      });
      input.addEventListener('blur', () => { clearTimeout(t); if (input.value !== (boot.answers[q.id] || '') || pending.has(String(q.id))) queueSave(q.id, input.value); });
      card.append(input);
      setTimeout(() => input.focus(), 0);
    } else {
      q.options.forEach((o, i) => {
        const b = el('button', 'choice' + (answers[q.id] === o.key ? ' sel' : ''));
        b.type = 'button';
        const label = q.type === 'tf' ? o.text[0] : String.fromCharCode(65 + i);
        b.append(el('span', 'ltr', label), el('span', '', o.text));
        b.addEventListener('click', () => choose(q, o.key));
        card.append(b);
      });
    }

    const nav = el('div', 'qnav');
    const left = el('div', 'row'), right = el('div', 'row');
    const prev = el('button', 'btn', '← Previous'); prev.type = 'button'; prev.disabled = idx === 0;
    prev.addEventListener('click', () => go(idx - 1));
    const flag = el('button', 'btn', flags.has(q.id) ? 'Unmark' : 'Mark for review'); flag.type = 'button';
    flag.addEventListener('click', () => {
      flags.has(q.id) ? flags.delete(q.id) : flags.add(q.id);
      try { localStorage.setItem(flagsKey, JSON.stringify([...flags])); } catch (e) { /* ignore */ }
      render();
    });
    left.append(prev, flag);
    if (answered(q)) {
      const clear = el('button', 'btn', 'Clear answer'); clear.type = 'button';
      clear.addEventListener('click', () => { answers[q.id] = ''; queueSave(q.id, ''); render(); });
      left.append(clear);
    }
    if (idx < Q.length - 1) {
      const next = el('button', 'btn primary', 'Next →'); next.type = 'button';
      next.addEventListener('click', () => go(idx + 1));
      right.append(next);
    } else {
      const fin = el('button', 'btn dark', 'Finish & submit'); fin.type = 'button';
      fin.addEventListener('click', askSubmit);
      right.append(fin);
    }
    nav.append(left, right);
    card.append(nav);
    paintPalette();
  }

  function paintPalette() {
    if (!grid.children.length) {
      Q.forEach((q, i) => {
        const b = el('button', '', String(i + 1)); b.type = 'button';
        b.addEventListener('click', () => go(i));
        grid.append(b);
      });
    }
    Q.forEach((q, i) => {
      const b = grid.children[i];
      b.className = (answered(q) ? 'done ' : '') + (flags.has(q.id) ? 'flag ' : '') + (i === idx ? 'cur' : '');
    });
    $('count').textContent = '(' + Q.filter(answered).length + '/' + Q.length + ' answered)';
  }

  function go(i) { if (i >= 0 && i < Q.length) { idx = i; render(); window.scrollTo({top: 0}); } }

  /* ---------------- timer ---------------- */
  const pad = n => String(n).padStart(2, '0');
  function tick() {
    const left = Math.max(0, Math.ceil((endAt - performance.now()) / 1000));
    const h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
    timerEl.textContent = (h ? h + ':' : '') + pad(m) + ':' + pad(s);
    timerEl.classList.toggle('low', left <= 300 && left > 60);
    timerEl.classList.toggle('crit', left <= 60);
    if (left <= 0 && !submitting) submit(true);
  }
  setInterval(tick, 250);
  tick();

  /* ---------------- submit ---------------- */
  const modal = $('modal'), busy = $('busy');
  function askSubmit() {
    const un = Q.filter(q => !answered(q)).length;
    const fl = Q.filter(q => flags.has(q.id)).length;
    let txt = un ? 'You have ' + un + ' unanswered question' + (un > 1 ? 's' : '') + '.' : 'You have answered every question.';
    if (fl) txt += ' ' + fl + ' marked for review.';
    $('modal-text').textContent = txt + ' You cannot change your answers after submitting.';
    modal.hidden = false;
  }
  $('finish-top').addEventListener('click', askSubmit);
  $('finish-side').addEventListener('click', askSubmit);
  $('cancel-submit').addEventListener('click', () => { modal.hidden = true; });
  $('confirm-submit').addEventListener('click', () => submit(false));

  async function submit(auto) {
    if (submitting) return;
    submitting = true; modal.hidden = true; busy.hidden = false;
    $('busy-text').textContent = auto ? "Time is up - submitting your exam…" : 'Submitting your exam…';
    try {
      const r = await post(boot.urls.submit, {answers});
      const j = await r.json();
      finished = true;
      window.location.href = j.redirect;
    } catch (e) {
      $('busy-text').textContent = 'No connection - retrying…';
      submitting = false;
      setTimeout(() => submit(true), 2000);               // keep trying until the server hears us
    }
  }

  /* ---------------- guards ---------------- */
  window.addEventListener('beforeunload', e => { if (!finished) { e.preventDefault(); e.returnValue = ''; } });
  let lastLeave = 0;
  const leave = () => {
    const t = Date.now();
    if (finished || t - lastLeave < 1500) return;
    lastLeave = t;
    post(boot.urls.flag, {}).then(r => r.json()).then(j => {
      if (j && j.locked) { finished = true; window.location.replace('/login'); }
    }).catch(() => {});
  };
  document.addEventListener('visibilitychange', () => { if (document.hidden) leave(); });
  if (boot.strict) {   // Strict mode also reacts to switching windows/apps (Alt+Tab, other monitor), not just tabs
    window.addEventListener('blur', () => setTimeout(() => { if (!document.hasFocus()) leave(); }, 400));
    const note = document.createElement('div');
    note.textContent = 'STRICT MODE: if you leave this page, your exam is submitted and your account is locked.';
    note.style.cssText = 'background:#7f1d1d;color:#fff;padding:8px 12px;text-align:center;font-weight:700;font-size:.85rem';
    document.body.prepend(note);
  }
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT' || modal.hidden === false) return;
    const q = Q[idx];
    if (e.key === 'ArrowRight') go(idx + 1);
    else if (e.key === 'ArrowLeft') go(idx - 1);
    else if (q.type === 'mcq') {
      const i = 'abcde'.indexOf(e.key.toLowerCase());
      if (i >= 0 && q.options[i]) choose(q, q.options[i].key);
    } else if (q.type === 'tf') {
      if (e.key.toLowerCase() === 't') choose(q, 'TRUE');
      if (e.key.toLowerCase() === 'f') choose(q, 'FALSE');
    }
  });

  render();
})();
