/* Rexx Hub - student exam screen.
   The server owns the clock: the deadline is fixed when the exam starts, every autosave
   returns the seconds left, and the server refuses answers after the deadline. */
(() => {
  const bootEl = document.getElementById('boot');
  const boot = JSON.parse(bootEl.textContent);
  const csrf = bootEl.dataset.csrf;
  const Q = boot.questions;
  const answers = Object.assign({}, boot.answers);       // question id (string) -> response
  const flagsKey = 'rexx-flags-' + boot.attemptId;
  let flags = new Set();
  try { flags = new Set(JSON.parse(localStorage.getItem(flagsKey) || '[]')); } catch (e) { /* ignore */ }

  const $ = id => document.getElementById(id);
  const card = $('qcard'), grid = $('pgrid'), timerEl = $('timer'), stateEl = $('savestate');
  const timeTxt = $('time-text'), timeBar = $('time-bar'), progBar = $('prog'), sheetEl = $('sheet');
  /* Local safety net: survives refresh, crash, power cut and server downtime on this computer. */
  const stKey = 'rexx-state-' + boot.attemptId;
  let st = {a: {}, i: null};
  try { st = Object.assign(st, JSON.parse(localStorage.getItem(stKey) || '{}')); } catch (e) { /* ignore */ }
  if (!st.a || typeof st.a !== 'object') st.a = {};
  const persist = () => { try { localStorage.setItem(stKey, JSON.stringify(st)); } catch (e) { /* ignore */ } };
  let idx = Number.isInteger(st.i) ? st.i : Number(boot.index) || 0;   // resume on the same question
  if (idx < 0 || idx >= Q.length) idx = 0;
  let endAt = performance.now() + boot.remaining * 1000;
  const total = Number(boot.total) || Number(boot.remaining) || 1;   // full exam length, for the time bar
  let submitting = false, finished = false;

  const post = (url, body) => fetch(url, {
    method: 'POST', credentials: 'same-origin', keepalive: true,
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf},
    body: JSON.stringify(body || {}),
  });

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };
  const answered = q => (answers[q.id] || '') !== '';

  /* ---------------- saving ---------------- */
  const pending = new Map();
  let flushing = false;
  const setState = (msg, bad) => { stateEl.textContent = msg; stateEl.classList.toggle('err', !!bad); };

  function queueSave(qid, value) {
    st.a[String(qid)] = {v: value, ts: Date.now()};      // written to this computer BEFORE it is sent
    persist();
    pending.set(String(qid), value);
    setState('Saving…');
    flush();
  }

  async function flush() {
    if (flushing) return;
    flushing = true;
    while (pending.size && !finished) {
      const [qid, value] = pending.entries().next().value;
      try {
        const r = await post(boot.urls.answer, {question_id: Number(qid), response: value});
        if (r.status === 409) {                        // clock ran out server side
          const j = await r.json();
          finished = true; window.location.href = j.redirect; return;
        }
        if (!r.ok) throw new Error('save failed');
        const j = await r.json();
        endAt = performance.now() + j.remaining * 1000; // re-sync with the server clock
        if (pending.get(qid) === value) {
          pending.delete(qid);
          if (st.a[qid] && st.a[qid].v === value) { delete st.a[qid]; persist(); }
        }
        setState('Saved ✓');
      } catch (e) {
        setState('Server unreachable - your answers are safe on this computer. Reconnecting…', true);
        flushing = false;
        setTimeout(flush, 2500);
        return;
      }
    }
    flushing = false;
  }

  /* ---------------- rendering: the question on paper, the answer sheet beside it ---------------- */
  let fresh = null;                                   // question just answered: its bubble gets the small pencil-in animation
  function choose(q, key) {
    answers[q.id] = key;
    fresh = q.id;
    queueSave(q.id, key);
    render();
  }
  const bubLabel = (q, i) => q.type === 'tf' ? q.options[i].text[0] : String.fromCharCode(65 + i);
  const optIndex = q => q.options ? q.options.findIndex(o => o.key === answers[q.id]) : -1;   // bubble position on screen

  function render() {
    const q = Q[idx];
    const freshQ = fresh; fresh = null;
    card.replaceChildren();

    const head = el('div', 'sx-qhead');
    head.append(el('span', 'sx-qno', 'Question ' + (idx + 1) + ' of ' + Q.length),
                el('span', '', q.marks + (q.marks === 1 ? ' mark' : ' marks')));
    card.append(head, el('div', 'sx-qtext', q.text));
    if (q.image) { const im = el('img', 'sx-qimg'); im.src = q.image; im.alt = 'Question diagram'; card.append(im); }

    if (q.type === 'short') {
      const input = el('input', 'sx-write');
      input.type = 'text'; input.placeholder = 'Write your answer here'; input.autocomplete = 'off';
      input.setAttribute('aria-label', 'Your answer');
      input.value = answers[q.id] || '';
      let t;
      input.addEventListener('input', () => {
        answers[q.id] = input.value;
        clearTimeout(t);
        t = setTimeout(() => queueSave(q.id, input.value), 600);
        paintPalette();
      });
      input.addEventListener('blur', () => { clearTimeout(t); if (input.value !== (boot.answers[q.id] || '') || pending.has(String(q.id))) queueSave(q.id, input.value); });
      card.append(input, el('p', 'sx-hint', 'Your answer saves as you type.'));
      setTimeout(() => input.focus(), 0);
    } else {
      const list = el('div', 'sx-opts');
      list.setAttribute('role', 'radiogroup'); list.setAttribute('aria-label', 'Choose one answer');
      q.options.forEach((o, i) => {
        const sel = answers[q.id] === o.key;
        const b = el('button', 'sx-opt' + (sel ? ' sel' : ''));
        b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', sel ? 'true' : 'false');
        b.append(el('span', 'sx-bub' + (sel ? ' on' : '') + (sel && freshQ === q.id ? ' fresh' : ''), bubLabel(q, i)),
                 el('span', '', o.text));
        b.addEventListener('click', () => choose(q, o.key));
        list.append(b);
      });
      card.append(list, el('p', 'sx-hint', q.type === 'tf'
        ? 'Keyboard: press T for true, F for false, and the arrow keys to move.'
        : 'Keyboard: press A to ' + String.fromCharCode(64 + q.options.length) + ' to choose, and the arrow keys to move.'));
    }

    const nav = el('div', 'sx-nav'), inner = el('div', 'sx-nav-in');
    const left = el('div'), right = el('div');
    const prev = el('button', 'sx-btn', 'Previous'); prev.type = 'button'; prev.disabled = idx === 0;
    prev.addEventListener('click', () => go(idx - 1));
    const flag = el('button', 'sx-btn flag', flags.has(q.id) ? 'Unmark' : 'Mark for review'); flag.type = 'button';
    flag.setAttribute('aria-pressed', flags.has(q.id) ? 'true' : 'false');
    flag.addEventListener('click', () => {
      flags.has(q.id) ? flags.delete(q.id) : flags.add(q.id);
      try { localStorage.setItem(flagsKey, JSON.stringify([...flags])); } catch (e) { /* ignore */ }
      render();
    });
    left.append(prev, flag);
    if (answered(q)) {
      const clear = el('button', 'sx-btn ghost', 'Clear answer'); clear.type = 'button';
      clear.addEventListener('click', () => { answers[q.id] = ''; queueSave(q.id, ''); render(); });
      left.append(clear);
    }
    if (idx < Q.length - 1) {
      const next = el('button', 'sx-btn next', 'Next'); next.type = 'button';
      next.addEventListener('click', () => go(idx + 1));
      right.append(next);
    } else {
      const fin = el('button', 'sx-btn go', 'Finish and submit'); fin.type = 'button';
      fin.addEventListener('click', askSubmit);
      right.append(fin);
    }
    inner.append(left, right); nav.append(inner); card.append(nav);
    paintPalette(freshQ);
  }

  /* The answer sheet: one row per question, bubbles filled in as you answer. */
  function paintPalette(freshQ) {
    if (!grid.children.length) {
      Q.forEach((q, i) => {
        const row = el('button', 'sx-row'); row.type = 'button';
        const bubs = el('span', 'sx-bubs');
        if (q.type === 'short') bubs.append(el('span', 'sx-written'));
        else q.options.forEach((o, k) => bubs.append(el('span', 'sx-bub', bubLabel(q, k))));
        row.append(el('span', 'sx-n', String(i + 1)), bubs, el('span', 'sx-flagmark'));
        row.addEventListener('click', () => { go(i); closeSheet(); });
        grid.append(row);
      });
    }
    Q.forEach((q, i) => {
      const row = grid.children[i], bubs = row.children[1];
      row.className = 'sx-row' + (flags.has(q.id) ? ' flag' : '') + (i === idx ? ' cur' : '');
      if (q.type === 'short') bubs.firstChild.textContent = answers[q.id] || '';
      else {
        const k = optIndex(q);
        Array.from(bubs.children).forEach((b, j) => { b.className = 'sx-bub' + (j === k ? ' on' + (freshQ === q.id ? ' fresh' : '') : ''); });
      }
      row.setAttribute('aria-label', 'Question ' + (i + 1) + ': ' + (answered(q) ? 'answered' : 'not answered') +
        (flags.has(q.id) ? ', marked for review' : '') + (i === idx ? ', current question' : ''));
      if (i === idx) row.setAttribute('aria-current', 'true'); else row.removeAttribute('aria-current');
    });
    const n = Q.filter(answered).length;
    $('count').textContent = n + ' of ' + Q.length + ' answered';
    progBar.style.width = (Q.length ? n / Q.length * 100 : 0) + '%';
    const sc = $('sheet-count'); if (sc) sc.textContent = n + '/' + Q.length;
    const cur = grid.children[idx];                    // keep the current row visible inside the sheet
    if (cur) {
      const top = cur.offsetTop, bot = top + cur.offsetHeight;
      if (top < grid.scrollTop) grid.scrollTop = Math.max(0, top - 8);
      else if (bot > grid.scrollTop + grid.clientHeight) grid.scrollTop = bot - grid.clientHeight + 8;
    }
  }

  function go(i) {
    if (i >= 0 && i < Q.length) {
      idx = i; st.i = i; persist(); render(); window.scrollTo({top: 0});
    }
  }

  /* ---------------- timer ---------------- */
  const pad = n => String(n).padStart(2, '0');
  function tick() {
    const left = Math.max(0, Math.ceil((endAt - performance.now()) / 1000));
    const h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
    timeTxt.textContent = (h ? h + ':' : '') + pad(m) + ':' + pad(s);
    timeBar.style.transform = 'scaleX(' + Math.max(0, Math.min(1, left / total)) + ')';
    timerEl.classList.toggle('low', left <= 300 && left > 60);
    timerEl.classList.toggle('crit', left <= 60);
    document.body.dataset.time = left <= 60 ? 'crit' : (left <= 300 ? 'low' : 'ok');
    if (left <= 0 && !submitting) submit(true);
  }
  setInterval(tick, 250);
  tick();

  /* ---------------- submit ---------------- */
  const modal = $('modal'), busy = $('busy');
  function askSubmit() {
    const un = Q.filter(q => !answered(q)).length;
    const fl = Q.filter(q => flags.has(q.id)).length;
    let txt = un ? 'You have ' + un + ' unanswered question' + (un > 1 ? 's' : '') + '.' : 'You have answered every question.';
    if (fl) txt += ' ' + fl + ' marked for review.';
    $('modal-text').textContent = txt + ' You cannot change your answers after submitting.';
    modal.hidden = false;
  }
  $('finish-top').addEventListener('click', askSubmit);
  $('finish-side').addEventListener('click', askSubmit);
  $('cancel-submit').addEventListener('click', () => { modal.hidden = true; });
  $('confirm-submit').addEventListener('click', () => submit(false));

  async function submit(auto) {
    if (submitting) return;
    submitting = true; modal.hidden = true; busy.hidden = false;
    $('busy-text').textContent = auto ? "Time is up - submitting your exam…" : 'Submitting your exam…';
    try {
      const r = await post(boot.urls.submit, {answers});
      const j = await r.json();
      finished = true;
      window.location.href = j.redirect;
    } catch (e) {
      $('busy-text').textContent = 'No connection - retrying…';
      submitting = false;
      setTimeout(() => submit(true), 2000);               // keep trying until the server hears us
    }
  }

  /* ---------------- recovery after a refresh / crash / server outage ---------------- */
  const skew = (Number(boot.serverNow) || 0) * 1000 - Date.now();   // this PC's clock vs the server's
  const validValue = (qu, v) => {
    if (typeof v !== 'string') return false;
    if (v === '') return true;
    if (qu.type === 'mcq') return qu.options.some(o => o.key === v);
    if (qu.type === 'tf') return v === 'TRUE' || v === 'FALSE';
    return v.length <= 500;
  };
  let recovered = 0;
  Object.keys(st.a).forEach(qid => {
    const r = st.a[qid], qu = Q.find(x => String(x.id) === qid);
    const serverTs = (Number((boot.savedAt || {})[qid]) || 0) * 1000;
    // Keep an unsynced local answer only if it belongs to this attempt, is well formed,
    // and is newer than whatever the server already holds for that question.
    if (!qu || !r || !validValue(qu, r.v) || !(r.ts + skew > serverTs - 1000)) { delete st.a[qid]; return; }
    answers[qid] = r.v; pending.set(qid, r.v); recovered++;
  });
  persist();
  if (pending.size) flush();

  /* ---------------- heartbeat (remembers position, detects the page being closed) ---------------- */
  let wasOffline = false;
  async function ping() {
    if (finished) return;
    try {
      const r = await post(boot.urls.ping, {index: idx});
      if (r.status === 409) { const j = await r.json(); finished = true; window.location.href = j.redirect; return; }
      if (!r.ok) throw new Error('ping');
      const j = await r.json();
      endAt = performance.now() + j.remaining * 1000;
      if (wasOffline) { wasOffline = false; if (!pending.size) setState('Reconnected - all saved ✓'); }
      flushViolations();
      if (pending.size) flush();
    } catch (e) { wasOffline = true; }
  }
  setInterval(ping, 10000);

  /* ---------------- guards ---------------- */
  window.addEventListener('beforeunload', e => { if (!finished) { e.preventDefault(); e.returnValue = ''; } });

  const gate = $('fsgate'), gateTitle = $('fs-title'), gateText = $('fs-text'), gateBtn = $('fs-btn');
  const fsOK = !!(document.documentElement.requestFullscreen);
  const inFS = () => !!document.fullscreenElement;
  let fsEntered = false, gateOpen = false, lastLeave = 0;
  const pendingKey = 'rexx-viol-' + boot.attemptId;
  let violations = [];
  try { violations = JSON.parse(localStorage.getItem(pendingKey) || '[]'); } catch (e) { violations = []; }
  const saveViolations = () => { try { localStorage.setItem(pendingKey, JSON.stringify(violations)); } catch (e) { /* ignore */ } };

  function showGate(title, text, btn) {
    gateTitle.textContent = title; gateText.textContent = text; gateBtn.textContent = btn;
    gate.hidden = false; gateOpen = true;
  }
  async function enterFS() {
    try { if (fsOK && !inFS()) await document.documentElement.requestFullscreen(); } catch (e) {
      gateText.textContent = 'Your browser blocked fullscreen. Press F11, then click the button again.';
      return;
    }
    fsEntered = fsOK; gate.hidden = true; gateOpen = false;
  }
  gateBtn.addEventListener('click', enterFS);

  function applyStrike(j) {
    if (!j) return;
    if (j.locked) { finished = true; window.location.replace('/login'); return; }
    if (j.ended) { finished = true; window.location.href = j.redirect; return; }
    if (j.strikes && j.max) {
      const left = j.max - j.strikes;
      showGate('Warning ' + j.strikes + ' of ' + j.max,
        'You left the exam screen. Your timer kept running. ' + left + ' more warning' + (left === 1 ? '' : 's') +
        ' and your exam will be submitted automatically. Your answers are safe.', fsOK ? 'Return to fullscreen and continue' : 'Continue exam');
    }
  }
  async function flushViolations() {
    while (violations.length && !finished) {
      try {
        const r = await post(boot.urls.flag, {kind: violations[0]});
        if (!r.ok) throw new Error('flag');
        violations.shift(); saveViolations();
        applyStrike(await r.json());
      } catch (e) { return; }               // server down: keep it and report when it is back
    }
  }
  const leave = kind => {
    const t = Date.now();
    if (finished || t - lastLeave < 1500) return;      // tab switch + fullscreen exit together = one strike
    lastLeave = t;
    if (kind === 'fullscreen_exit' || (boot.maxStrikes && !boot.strict)) {
      showGate('Exam paused', 'You left the exam screen. This has been recorded. Click below to continue.',
               fsOK ? 'Return to fullscreen and continue' : 'Continue exam');
    }
    violations.push(kind); saveViolations();
    flushViolations();
  };
  document.addEventListener('visibilitychange', () => { if (document.hidden) leave('tab_switch'); });
  document.addEventListener('fullscreenchange', () => { if (!inFS() && fsEntered && !finished) leave('fullscreen_exit'); });
  if (violations.length) flushViolations();
  if (fsOK) {
    showGate(recovered || idx || Object.keys(boot.answers).length ? 'Welcome back' : 'Ready to begin',
      recovered ? 'Your exam is exactly where you left it, and ' + recovered + ' unsaved answer' + (recovered === 1 ? ' was' : 's were') + ' recovered. The timer never stopped.'
                : 'This exam runs in fullscreen. Click below to ' + (idx || Object.keys(boot.answers).length ? 'continue where you stopped.' : 'begin.'),
      'Enter fullscreen and continue');
  }
  if (boot.strict) {   // Strict mode also reacts to switching windows/apps (Alt+Tab, other monitor), not just tabs
    window.addEventListener('blur', () => setTimeout(() => { if (!document.hasFocus()) leave('tab_switch'); }, 400));
    const note = document.createElement('div');
    note.textContent = 'STRICT MODE: if you leave this page, your exam is submitted and your account is locked.';
    note.style.cssText = 'background:#7f1d1d;color:#fff;padding:8px 12px;text-align:center;font-weight:700;font-size:.85rem';
    document.body.prepend(note);
  } else if (boot.maxStrikes) {
    window.addEventListener('blur', () => setTimeout(() => { if (!document.hasFocus() && !gateOpen) leave('tab_switch'); }, 400));
  }
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT' || modal.hidden === false || gateOpen) return;
    const q = Q[idx];
    if (e.key === 'ArrowRight') go(idx + 1);
    else if (e.key === 'ArrowLeft') go(idx - 1);
    else if (q.type === 'mcq') {
      const i = 'abcde'.indexOf(e.key.toLowerCase());
      if (i >= 0 && q.options[i]) choose(q, q.options[i].key);
    } else if (q.type === 'tf') {
      if (e.key.toLowerCase() === 't') choose(q, 'TRUE');
      if (e.key.toLowerCase() === 'f') choose(q, 'FALSE');
    }
  });

  /* ---------------- phones: the answer sheet slides up as a drawer ---------------- */
  const sheetBtn = $('sheet-toggle');
  function closeSheet() {
    if (sheetEl.classList.contains('open')) { sheetEl.classList.remove('open'); if (sheetBtn) sheetBtn.setAttribute('aria-expanded', 'false'); }
  }
  $('sheet-close').addEventListener('click', closeSheet);
  if (sheetBtn) sheetBtn.addEventListener('click', () => {
    const open = sheetEl.classList.toggle('open');
    sheetBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  render();
})();
