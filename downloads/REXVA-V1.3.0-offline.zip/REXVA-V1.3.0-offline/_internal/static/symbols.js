/* REXVA CBT: symbols and formulas for the teacher's question editor.
   Adds a "Symbols and formulas" panel to every question form. A click inserts the symbol or formula
   where the cursor is in the Question, an Option or the Accepted answer box. Plain text only, so it
   works offline and shows the same on every student's computer. */
(function () {
  'use strict';

  /* tiny helpers: 'a b c' -> ['a','b','c'];  an item may be 'symbol|what it is' */
  const S = s => s.trim().split(/\s+/);

  /* ------------------------------------------------------------------ the data */
  const DATA = [
    { id: 'maths', name: 'Mathematics', groups: [
      { t: 'Operations and relations', s: S('+ − × ÷ ± ∓ ·|dot ∗ ∘ = ≠|not equal ≈|approximately ≡|identical ≅|congruent ∼|similar ∝|proportional to < > ≤|less than or equal ≥|greater than or equal ≪ ≫ ∞|infinity %|percent ‰|per mille ∴|therefore ∵|because ∣|divides ! ° ′|minutes or prime ″|seconds') },
      { t: 'Powers, roots and fractions', s: ['²|squared', '³|cubed', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰', 'ⁿ', '⁻¹|to the power minus 1', '⁻²', '⁺', '⁻', '½', '⅓', '⅔', '¼', '¾', '⅕', '⅖', '⅗', '⅘', '⅙', '⅚', '⅛', '⅜', '⅝', '⅞', '√|square root', '∛|cube root', '∜|fourth root', '√( )|square root of a bracket', 'ⁿ√|nth root', '( ) / ( )|fraction', 'x²', 'x³', 'xⁿ', 'x⁻¹', 'aᵐ', 'aᵐ⁺ⁿ', 'aᵐ⁻ⁿ', 'a⁻ⁿ', 'a⁰'] },
      { t: 'Subscripts', s: S('₀ ₁ ₂ ₃ ₄ ₅ ₆ ₇ ₈ ₉ ₊ ₋ ₙ ₐ ᵢ ⱼ x₁ x₂ y₁ y₂ a₁ a₂ aₙ Tₙ Sₙ') },
      { t: 'Sets and logic', s: S('∈|element of ∉|not an element of ∋ ⊂|proper subset ⊃ ⊆|subset ⊇ ⊄ ∪|union ∩|intersection ∅|empty set ξ|universal set ℕ ℤ ℚ ℝ ℂ ∀|for all ∃|there exists ∄ ¬|not ∧|and ∨|or ⇒|implies ⇔|if and only if ⇐ → ← ↔ ↦ { } ⟨ ⟩ ∖|set difference A′|complement of A n(A)|number of elements n(A∪B) n(A∩B) |A| ∣x∣') },
      { t: 'Geometry and trigonometry', s: ['∠|angle', '∟|right angle', '△|triangle', '▱', '□', '○', '⌒|arc', '⊙', '⊥|perpendicular', '∥|parallel', '≅', '∼', '°', '′', '″', 'π', 'θ', 'α', 'β', 'γ', 'δ', 'φ', 'ω', '∠ABC', '△ABC', 'sin ', 'cos ', 'tan ', 'sin⁻¹ ', 'cos⁻¹ ', 'tan⁻¹ ', 'cosec ', 'sec ', 'cot ', 'sin²θ', 'cos²θ', 'tan²θ', 'log ', 'ln ', 'log₁₀ ', 'logₐ ', 'mod', 'max', 'min'] },
      { t: 'Statistics, algebra and calculus', s: ['Σ|sum', 'Π|product', 'Δ|change in', '∂|partial', 'x̄|mean of x', 'ȳ', 'σ|standard deviation', 'μ|mean', 'σ²|variance', 'Σfx', 'Σf', 'Σx²', 'n!', 'ⁿCᵣ|combination', 'ⁿPᵣ|permutation', '⌊ ⌋|floor', '⌈ ⌉|ceiling', '|x|', '∫|integral', '∬', '∮', 'dy/dx', 'd²y/dx²', 'd/dx', '∫ₐᵇ|definite integral', 'lim|limit', 'x → ∞', 'x → a', "f′(x)", "f″(x)", 'Δx', 'δx'] },
      { t: 'Formulas', f: [
        ['Quadratic formula', 'x = (−b ± √(b² − 4ac)) / 2a'],
        ['Discriminant', 'b² − 4ac'],
        ['Difference of two squares', 'a² − b² = (a + b)(a − b)'],
        ['Square of a sum', '(a + b)² = a² + 2ab + b²'],
        ['Square of a difference', '(a − b)² = a² − 2ab + b²'],
        ['Sum / difference of cubes', 'a³ ± b³ = (a ± b)(a² ∓ ab + b²)'],
        ['Laws of indices', 'aᵐ × aⁿ = aᵐ⁺ⁿ;  aᵐ ÷ aⁿ = aᵐ⁻ⁿ;  (aᵐ)ⁿ = aᵐⁿ;  a⁰ = 1;  a⁻ⁿ = 1/aⁿ'],
        ['Laws of logarithms', 'log(ab) = log a + log b;  log(a/b) = log a − log b;  log aⁿ = n log a'],
        ['Change of base', 'logₐ b = log b / log a'],
        ['Pythagoras', 'a² + b² = c²'],
        ['Area of a triangle', 'A = ½ × base × height'],
        ['Area of a triangle (sine)', 'A = ½ab sin C'],
        ['Area of a trapezium', 'A = ½(a + b)h'],
        ['Circle', 'A = πr²;  C = 2πr'],
        ['Arc and sector', 'Arc length = (θ/360) × 2πr;  Sector area = (θ/360) × πr²'],
        ['Volumes', 'Cylinder V = πr²h;  Cone V = ⅓πr²h;  Sphere V = 4/3 πr³'],
        ['Surface areas', 'Cylinder = 2πr(r + h);  Cone = πr(r + l);  Sphere = 4πr²'],
        ['Sine rule', 'a/sin A = b/sin B = c/sin C'],
        ['Cosine rule', 'a² = b² + c² − 2bc cos A'],
        ['Trig identities', 'sin²θ + cos²θ = 1;  tan θ = sin θ / cos θ'],
        ['Gradient of a line', 'm = (y₂ − y₁) / (x₂ − x₁)'],
        ['Equation of a line', 'y = mx + c;  y − y₁ = m(x − x₁)'],
        ['Distance between two points', 'd = √((x₂ − x₁)² + (y₂ − y₁)²)'],
        ['Mid-point', '((x₁ + x₂)/2, (y₁ + y₂)/2)'],
        ['Arithmetic progression (AP)', 'Tₙ = a + (n − 1)d;  Sₙ = n/2 [2a + (n − 1)d]'],
        ['Geometric progression (GP)', 'Tₙ = arⁿ⁻¹;  Sₙ = a(rⁿ − 1)/(r − 1);  S∞ = a/(1 − r)'],
        ['Simple interest', 'I = PRT/100'],
        ['Compound interest', 'A = P(1 + r/100)ⁿ'],
        ['Mean from a frequency table', 'x̄ = Σfx / Σf'],
        ['Standard deviation', 'σ = √(Σf(x − x̄)² / Σf)'],
        ['Probability', 'P(A) = n(A)/n(S);  P(A ∪ B) = P(A) + P(B) − P(A ∩ B)'],
        ['Variation', 'y ∝ x, y = kx;  y ∝ 1/x, y = k/x'],
        ['Sum of angles in a polygon', '(n − 2) × 180°'],
        ['Bearing', 'Bearing of B from A = 0°–360° measured clockwise from North']
      ] }
    ] },

    { id: 'further', name: 'Further Maths', groups: [
      { t: 'Vectors and matrices', s: ['a⃗|vector a', 'AB⃗|vector AB', 'î', 'ĵ', 'k̂', '|a|', 'a · b|dot product', 'a × b|cross product', '[ a  b ]', 'Aᵀ|transpose', 'A⁻¹|inverse', '|A|', 'det A', 'I|identity matrix', '⎡ ⎤', '⎣ ⎦', '( a  b )', '→'] },
      { t: 'Complex numbers', s: ['i|imaginary unit', 'i² = −1', 'z = a + bi', 'z̄|conjugate', '|z|', 'arg z', 'Re(z)', 'Im(z)', 'ℂ', 'r(cos θ + i sin θ)', 'e^(iθ)'] },
      { t: 'Functions and series', s: ['Σ|sum', 'Σᵣ₌₁ⁿ', '∞', '∫|integral', '∫ₐᵇ', 'sinh', 'cosh', 'tanh', 'sinh⁻¹', 'cosh⁻¹', 'f ∘ g|composite', 'f⁻¹(x)', 'ⁿCᵣ', 'ⁿPᵣ', '∂', 'Δ', '→', '⇒', '≡', 'ln x', 'eˣ', 'e⁻ˣ', '(x, y)', 'x → ∞'] },
      { t: 'Formulas', f: [
        ['Determinant (2 × 2)', 'det A = ad − bc'],
        ['Inverse (2 × 2)', 'A⁻¹ = (1/(ad − bc)) [ d  −b ; −c  a ]'],
        ['Matrix, 2 × 2', '[ a  b ]\n[ c  d ]'],
        ['Matrix, 3 × 3', '[ a  b  c ]\n[ d  e  f ]\n[ g  h  i ]'],
        ['Column vector', '( x )\n( y )'],
        ['Magnitude of a vector', '|a| = √(x² + y² + z²)'],
        ['Scalar product', 'a · b = |a||b| cos θ = x₁x₂ + y₁y₂ + z₁z₂'],
        ['Vector product', '|a × b| = |a||b| sin θ'],
        ['Modulus and argument', '|z| = √(a² + b²);  arg z = tan⁻¹(b/a)'],
        ['Euler / polar form', 'e^(iθ) = cos θ + i sin θ'],
        ["De Moivre's theorem", '(cos θ + i sin θ)ⁿ = cos nθ + i sin nθ'],
        ['Roots of a quadratic', 'α + β = −b/a;  αβ = c/a'],
        ['Binomial theorem', '(a + b)ⁿ = Σ ⁿCᵣ aⁿ⁻ʳ bʳ'],
        ['Combination / permutation', 'ⁿCᵣ = n! / (r!(n − r)!);  ⁿPᵣ = n! / (n − r)!'],
        ['Power rule', 'd/dx (xⁿ) = nxⁿ⁻¹'],
        ['Product rule', 'd/dx (uv) = u dv/dx + v du/dx'],
        ['Quotient rule', 'd/dx (u/v) = (v du/dx − u dv/dx) / v²'],
        ['Chain rule', 'dy/dx = dy/du × du/dx'],
        ['Standard derivatives', 'd/dx (sin x) = cos x;  d/dx (cos x) = −sin x;  d/dx (eˣ) = eˣ;  d/dx (ln x) = 1/x'],
        ['Integration of a power', '∫ xⁿ dx = xⁿ⁺¹/(n + 1) + c,  n ≠ −1'],
        ['Integration by parts', '∫ u dv = uv − ∫ v du'],
        ['Area under a curve', 'A = ∫ₐᵇ y dx'],
        ['Volume of revolution', 'V = π ∫ₐᵇ y² dx'],
        ['Newton–Raphson', 'xₙ₊₁ = xₙ − f(xₙ)/f′(xₙ)'],
        ['Maclaurin series', 'f(x) = f(0) + x f′(0) + x²/2! f″(0) + …'],
        ['Conics', 'Parabola y² = 4ax;  Ellipse x²/a² + y²/b² = 1;  Hyperbola x²/a² − y²/b² = 1'],
        ['Equation of a circle', '(x − a)² + (y − b)² = r²'],
        ['Mechanics: motion', 'v = u + at;  s = ut + ½at²;  v² = u² + 2as'],
        ['Projectile', 'T = 2u sin θ / g;  R = u² sin 2θ / g;  H = u² sin²θ / 2g'],
        ['Momentum and impulse', 'p = mv;  Impulse = Ft = mv − mu'],
        ['Hypothesis testing', 'H₀: μ = μ₀;  H₁: μ ≠ μ₀;  z = (x̄ − μ) / (σ/√n)'],
        ['Regression line', 'y = a + bx'],
        ['Correlation', 'r = Sxy / √(Sxx Syy)']
      ] }
    ] },

    { id: 'physics', name: 'Physics', groups: [
      { t: 'Symbols', s: S('Δ|change in Ω|ohm ω|angular speed μ ν λ|wavelength ρ|density σ τ φ θ η ε ε₀ μ₀ α β γ π ± ∝ ≈ ≤ ≥ → ⃗ ∞ ° ∑ ∫ Σ ·|dot × ∠') },
      { t: 'Units', s: S('m s kg N J W Pa Hz A V Ω C F H T Wb K °C mol cd rad eV kWh km/h µm µF µA µs µC nm ms kΩ MΩ mA kV MHz GHz cm³ dm³ m² m³'), s2: ['m s⁻¹', 'm s⁻²', 'kg m⁻³', 'N m⁻²', 'N kg⁻¹', 'N m', 'J kg⁻¹ K⁻¹', 'J kg⁻¹', 'W m⁻²', 'V m⁻¹', 'mol dm⁻³', 'g cm⁻³', 'rad s⁻¹', 'Ω m', 'A m⁻¹'] },
      { t: 'Powers of ten', s: ['× 10⁻¹⁹', '× 10⁻¹¹', '× 10⁻⁹', '× 10⁻⁶', '× 10⁻³', '× 10³', '× 10⁶', '× 10⁸', '× 10⁹', '× 10²³', '× 10⁻³⁴', '× 10ⁿ', '10⁻¹', '10⁻²', '10⁻³', '10⁻⁶', '10⁻⁹', '10⁻¹²', '10³', '10⁶', '10⁹'] },
      { t: 'Formulas: motion and forces', f: [
        ['Velocity and speed', 'v = d/t;  a = (v − u)/t'],
        ['Equations of motion', 'v = u + at;  s = ut + ½at²;  v² = u² + 2as;  s = ½(u + v)t'],
        ["Newton's second law", 'F = ma'],
        ['Weight', 'W = mg'],
        ['Momentum and impulse', 'p = mv;  Ft = mv − mu'],
        ['Conservation of momentum', 'm₁u₁ + m₂u₂ = m₁v₁ + m₂v₂'],
        ['Friction', 'F = μR'],
        ['Moment of a force', 'Moment = F × d'],
        ["Hooke's law", 'F = ke;  E = ½ke²'],
        ['Projectile', 'T = 2u sin θ / g;  R = u² sin 2θ / g;  H = u² sin²θ / 2g'],
        ['Circular motion', 'v = ωr;  ω = 2πf;  a = v²/r = ω²r;  F = mv²/r'],
        ['Gravitation', 'F = Gm₁m₂/r²;  g = GM/R²'],
        ['Frequency and period', 'f = 1/T']
      ] },
      { t: 'Formulas: work, energy and pressure', f: [
        ['Work', 'W = Fs cos θ'],
        ['Kinetic energy', 'KE = ½mv²'],
        ['Potential energy', 'PE = mgh'],
        ['Power', 'P = W/t = Fv'],
        ['Efficiency', 'Efficiency = (useful output / input) × 100%'],
        ['Machines', 'MA = Load/Effort;  VR = distance moved by effort / distance moved by load;  Efficiency = MA/VR × 100%'],
        ['Density', 'ρ = m/V;  Relative density = ρ(substance)/ρ(water)'],
        ['Pressure', 'P = F/A;  P = ρgh'],
        ["Archimedes' principle", 'Upthrust = weight of fluid displaced = ρVg']
      ] },
      { t: 'Formulas: heat and gases', f: [
        ['Heat energy', 'Q = mcΔθ'],
        ['Latent heat', 'Q = mL'],
        ['Linear expansion', 'ΔL = αLΔθ'],
        ["Boyle's law", 'PV = constant;  P₁V₁ = P₂V₂'],
        ["Charles' law", 'V/T = constant;  V₁/T₁ = V₂/T₂'],
        ['Pressure law', 'P/T = constant'],
        ['General gas law', 'P₁V₁/T₁ = P₂V₂/T₂;  PV = nRT'],
        ['Kelvin scale', 'T(K) = θ(°C) + 273']
      ] },
      { t: 'Formulas: waves, light and sound', f: [
        ['Wave equation', 'v = fλ'],
        ["Snell's law", 'n = sin i / sin r;  n = c/v'],
        ['Lens / mirror equation', '1/f = 1/u + 1/v'],
        ['Magnification', 'm = v/u = image height / object height'],
        ['Critical angle', 'sin C = 1/n'],
        ['Speed of sound in a pipe', 'Closed pipe: λ = 4L;  Open pipe: λ = 2L'],
        ['Doppler / beats', 'Beat frequency = |f₁ − f₂|']
      ] },
      { t: 'Formulas: electricity and magnetism', f: [
        ["Ohm's law", 'V = IR'],
        ['Charge and current', 'Q = It'],
        ['Electrical power', 'P = IV = I²R = V²/R'],
        ['Electrical energy', 'E = VIt = Pt'],
        ['Resistance of a wire', 'R = ρL/A'],
        ['Resistors in series', 'R = R₁ + R₂ + R₃'],
        ['Resistors in parallel', '1/R = 1/R₁ + 1/R₂ + 1/R₃'],
        ['EMF and internal resistance', 'E = V + Ir'],
        ['Capacitor', 'C = Q/V;  E = ½CV²;  Series: 1/C = 1/C₁ + 1/C₂;  Parallel: C = C₁ + C₂'],
        ['Magnetic force', 'F = BIL sin θ;  F = Bqv'],
        ["Faraday's law", 'ε = −N ΔΦ/Δt'],
        ['Transformer', 'Vₛ/Vₚ = Nₛ/Nₚ = Iₚ/Iₛ'],
        ['AC values', 'V(rms) = V₀/√2;  I(rms) = I₀/√2'],
        ["Coulomb's law", 'F = kq₁q₂/r²'],
        ['Electric field', 'E = F/q = V/d']
      ] },
      { t: 'Formulas: modern physics and constants', f: [
        ['Photon energy', 'E = hf = hc/λ'],
        ['Photoelectric effect', 'hf = φ + ½mv²max'],
        ['Mass-energy', 'E = mc²'],
        ['Radioactive decay', 'N = N₀e^(−λt);  t½ = 0.693/λ'],
        ['Acceleration due to gravity', 'g = 9.8 m s⁻²  (10 m s⁻² in some questions)'],
        ['Speed of light', 'c = 3.0 × 10⁸ m s⁻¹'],
        ['Gravitational constant', 'G = 6.67 × 10⁻¹¹ N m² kg⁻²'],
        ["Planck's constant", 'h = 6.63 × 10⁻³⁴ J s'],
        ['Electron charge', 'e = 1.6 × 10⁻¹⁹ C'],
        ['Molar gas constant', 'R = 8.31 J mol⁻¹ K⁻¹'],
        ["Avogadro's number", 'Nₐ = 6.02 × 10²³ mol⁻¹']
      ] }
    ] },

    { id: 'chem', name: 'Chemistry', groups: [
      { t: 'Arrows and state symbols', s: ['→|yields', '⇌|reversible reaction', '⇄', '⟶', '⟵', '↑|gas given off', '↓|precipitate', 'Δ|heat', '(s)', '(l)', '(g)', '(aq)', '°C', 'ΔH', 'ΔS', 'ΔG', 'ΔH°', 'E°', '⁰', '•|radical', '−|single bond', '=|double bond', '≡|triple bond', '·|water of crystallisation', '+', '→ (heat)', '→ (catalyst)', '⇌ (Fe, 450 °C, 200 atm)'] },
      { t: 'Subscripts and charges', s: S('₀ ₁ ₂ ₃ ₄ ₅ ₆ ₇ ₈ ₉ ⁺ ⁻ ²⁺ ²⁻ ³⁺ ³⁻ ⁴⁺ ⁴⁻ ¹⁰ ⁻¹ ⁻² ⁻³ ⁻⁹ ²³') },
      { t: 'Common compounds', s: S('H₂O CO₂ CO SO₂ SO₃ NO NO₂ N₂O N₂O₄ H₂ O₂ N₂ Cl₂ Br₂ I₂ O₃ H₂O₂ HCl HNO₃ H₂SO₄ H₃PO₄ H₂CO₃ CH₃COOH NaOH KOH Ca(OH)₂ Mg(OH)₂ Al(OH)₃ NH₃ NaCl KCl CaCO₃ CaO MgO Na₂CO₃ NaHCO₃ Na₂SO₄ CuSO₄ CuSO₄·5H₂O FeSO₄ ZnSO₄ KNO₃ AgNO₃ Pb(NO₃)₂ BaCl₂ KMnO₄ K₂Cr₂O₇ Fe₂O₃ Fe₃O₄ Al₂O₃ SiO₂ NH₄Cl (NH₄)₂SO₄ CH₄ C₂H₆ C₃H₈ C₄H₁₀ C₂H₄ C₂H₂ C₆H₆ C₂H₅OH CH₃OH C₆H₁₂O₆ C₁₂H₂₂O₁₁ HCOOH') },
      { t: 'Ions', s: S('H⁺ H₃O⁺ OH⁻ Na⁺ K⁺ Li⁺ Ag⁺ NH₄⁺ Ca²⁺ Mg²⁺ Zn²⁺ Cu²⁺ Fe²⁺ Fe³⁺ Pb²⁺ Ba²⁺ Al³⁺ Cl⁻ Br⁻ I⁻ F⁻ O²⁻ S²⁻ NO₃⁻ NO₂⁻ SO₄²⁻ SO₃²⁻ CO₃²⁻ HCO₃⁻ PO₄³⁻ MnO₄⁻ Cr₂O₇²⁻ CrO₄²⁻ CH₃COO⁻ ClO₃⁻ e⁻') },
      { t: 'Isotopes and radiation', s: S('¹₁H ²₁H ³₁H ⁴₂He ¹²₆C ¹³₆C ¹⁴₆C ¹⁶₈O ²³₁₁Na ³⁵₁₇Cl ³⁷₁₇Cl ²³⁸₉₂U ²³⁵₉₂U ²²⁶₈₈Ra ⁰₋₁e ⁰₊₁e ¹₀n α β γ ᴬ_ZX') },
      { t: 'Organic groups and electron configuration', s: ['–OH|hydroxyl (alcohol)', '–COOH|carboxylic acid', '–CHO|aldehyde', '–CO–|ketone', '–COO–|ester', '–NH₂|amine', '–CONH₂|amide', '–Cl', '–Br', '–NO₂', 'C=C', 'C≡C', 'CH₃–', 'C₂H₅–', '–CH₂–', '1s²', '2s²', '2p⁶', '3s²', '3p⁶', '4s²', '3d¹⁰', '1s² 2s² 2p⁶ 3s²', '[Ne] 3s²', '[Ar] 4s²'] },
      { t: 'Equations', f: [
        ['Water formation', '2H₂ + O₂ → 2H₂O'],
        ['Haber process', 'N₂(g) + 3H₂(g) ⇌ 2NH₃(g)'],
        ['Contact process', '2SO₂(g) + O₂(g) ⇌ 2SO₃(g)'],
        ['Neutralisation', 'NaOH + HCl → NaCl + H₂O'],
        ['Thermal decomposition', 'CaCO₃(s) → CaO(s) + CO₂(g)'],
        ['Metal and acid', 'Zn(s) + 2HCl(aq) → ZnCl₂(aq) + H₂(g)'],
        ['Combustion of methane', 'CH₄ + 2O₂ → CO₂ + 2H₂O'],
        ['Photosynthesis', '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂'],
        ['Fermentation', 'C₆H₁₂O₆ → 2C₂H₅OH + 2CO₂'],
        ['Esterification', 'CH₃COOH + C₂H₅OH ⇌ CH₃COOC₂H₅ + H₂O'],
        ['Precipitation (ionic)', 'Ag⁺(aq) + Cl⁻(aq) → AgCl(s)'],
        ['Half-equation (reduction)', 'Cu²⁺ + 2e⁻ → Cu'],
        ['Half-equation (oxidation)', 'Zn → Zn²⁺ + 2e⁻']
      ] },
      { t: 'Formulas and constants', f: [
        ['Amount of substance', 'n = m/M;  n = N/Nₐ'],
        ['Gas volume', 'n = V/22.4 dm³ at s.t.p.;  n = V/24 dm³ at r.t.p.'],
        ['Concentration', 'c = n/V;  c (g dm⁻³) = c (mol dm⁻³) × M'],
        ['Dilution', 'c₁V₁ = c₂V₂'],
        ['Titration (acid–base)', 'cₐVₐ / cᵦVᵦ = nₐ / nᵦ'],
        ['Percentage composition', '% of element = (mass of element / molar mass) × 100'],
        ['Percentage yield', '% yield = (actual yield / theoretical yield) × 100'],
        ['Relative atomic mass', 'Aᵣ = Σ(isotopic mass × abundance) / 100'],
        ['Gas law', 'PV = nRT;  P₁V₁/T₁ = P₂V₂/T₂'],
        ["Graham's law", 'R₁/R₂ = √(M₂/M₁)'],
        ['pH', 'pH = −log[H⁺];  pOH = −log[OH⁻];  pH + pOH = 14'],
        ['Ionic product of water', 'Kw = [H⁺][OH⁻] = 1 × 10⁻¹⁴ mol² dm⁻⁶'],
        ['Equilibrium constant', 'Kc = [C]ᶜ[D]ᵈ / [A]ᵃ[B]ᵇ'],
        ['Rate of reaction', 'Rate = k[A]ᵐ[B]ⁿ;  Rate = change in concentration / time'],
        ['Enthalpy change', 'ΔH = Σ(bonds broken) − Σ(bonds formed);  Q = mcΔT'],
        ['Electrolysis (Faraday)', 'Q = It;  m = (M × I × t) / (n × F);  F = 96 500 C mol⁻¹'],
        ['Avogadro constant', 'Nₐ = 6.02 × 10²³ mol⁻¹'],
        ['Molar volume', '22.4 dm³ mol⁻¹ (s.t.p.);  24 dm³ mol⁻¹ (r.t.p.)']
      ] }
    ] },

    { id: 'bio', name: 'Biology', groups: [
      { t: 'Symbols', s: ['♂|male', '♀|female', '×|cross', '→', '⇌', '↑', '↓', '°C', 'µm|micrometre', 'mm', 'nm', 'm²', '%', 'P₁', 'F₁', 'F₂', 'Aa', 'AA', 'aa', 'Bb', 'BB', 'bb', 'XX', 'XY', 'Xᴴ', 'Xʰ', 'Iᴬ', 'Iᴮ', 'i', 'Q₁₀', 'CO₂', 'O₂', 'H₂O', 'ATP', 'ADP', 'C₆H₁₂O₆', '±', 'p', 'q'] },
      { t: 'Equations and formulas', f: [
        ['Photosynthesis', '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂  (light, chlorophyll)'],
        ['Aerobic respiration', 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energy'],
        ['Anaerobic respiration (yeast)', 'C₆H₁₂O₆ → 2C₂H₅OH + 2CO₂ + energy'],
        ['Anaerobic respiration (muscle)', 'C₆H₁₂O₆ → 2C₃H₆O₃ + energy'],
        ['Magnification', 'Magnification = image size / actual size'],
        ['Cross (monohybrid)', 'Aa × Aa → AA : Aa : aa  =  1 : 2 : 1'],
        ['Cross (test cross)', 'Aa × aa → Aa : aa  =  1 : 1'],
        ['Hardy–Weinberg', 'p + q = 1;  p² + 2pq + q² = 1'],
        ['Population density', 'Population density = number of individuals / area'],
        ['Population (capture–recapture)', 'N = (n₁ × n₂) / m'],
        ['Surface area to volume ratio', 'SA : V = surface area / volume'],
        ['Percentage change', '% change = (change / original) × 100'],
        ['Rate', 'Rate = change in quantity / time'],
        ['Rf value', 'Rf = distance moved by the substance / distance moved by the solvent'],
        ['Temperature coefficient', 'Q₁₀ = rate at (T + 10) °C / rate at T °C'],
        ['Energy transfer', 'Efficiency = (energy passed on / energy received) × 100%']
      ] }
    ] },

    { id: 'english', name: 'English', groups: [
      { t: 'Punctuation and typing', s: S('“ ” ‘ ’ — – … ¶ § † ‡ • · ¿ ¡ « » ‹ › ′ ″ ° © ® ™ ★ ✓ ✗ → ←') },
      { t: 'Accented letters (loan words)', s: S('é è ê ë á à â ä í ì î ï ó ò ô ö ú ù û ü ç ñ œ æ ß É À Ç') },
      { t: 'Oral English: vowels', s: ['iː|as in seat', 'ɪ|as in sit', 'e|as in bed', 'æ|as in bad', 'ɑː|as in car', 'ɒ|as in hot', 'ɔː|as in saw', 'ʊ|as in put', 'uː|as in food', 'ʌ|as in cut', 'ɜː|as in bird', 'ə|schwa, as in about', 'eɪ|as in day', 'aɪ|as in high', 'ɔɪ|as in boy', 'əʊ|as in go', 'aʊ|as in now', 'ɪə|as in here', 'eə|as in hair', 'ʊə|as in tour', 'i|as in happy', 'u|as in influence', 'ɛ', 'ɔ', 'ɑ'] },
      { t: 'Oral English: consonants', s: ['p', 'b', 't', 'd', 'k', 'ɡ|g as in go', 'f', 'v', 'θ|th as in thin', 'ð|th as in this', 's', 'z', 'ʃ|sh as in ship', 'ʒ|s as in measure', 'h', 'tʃ|ch as in chin', 'dʒ|j as in jam', 'm', 'n', 'ŋ|ng as in sing', 'l', 'r', 'j|y as in yes', 'w', 'ʔ', 'ɹ'] },
      { t: 'Stress, length and brackets', s: ['ˈ|primary stress', 'ˌ|secondary stress', 'ː|long', '‿|linking', '/ /|phonemic transcription', '[ ]|phonetic transcription', '/ˈ', '(  )', '→', '↗|rising tone', '↘|falling tone'] },
      { t: 'Grammar labels', s: ['(n.)|noun', '(v.)|verb', '(adj.)|adjective', '(adv.)|adverb', '(prep.)|preposition', '(conj.)|conjunction', '(pron.)|pronoun', '(det.)|determiner', '(interj.)|interjection', 'e.g.', 'i.e.', 'etc.', 'viz.', 'cf.', 'N.B.', 'Mr.', 'Mrs.', 'Dr.', 'Prof.', 'St.', '________|blank to fill in', '___________'] }
    ] },

    { id: 'ict', name: 'Digital Technology', groups: [
      { t: 'Logic and Boolean', s: ['∧|AND', '∨|OR', '¬|NOT', '⊕|XOR', '⊼|NAND', '⊽|NOR', '⇒', '⇔', '≡', '·|AND (dot)', '+|OR (plus)', 'A̅|NOT A', 'B̅', 'Ā·B', 'A + B̅', '(A + B)′', 'A′', 'A · B', 'A + B', 'A ⊕ B', '0', '1', 'TRUE', 'FALSE', '≤', '≥', '≠', '=='] },
      { t: 'Number bases and units', s: ['₂|binary', '₈|octal', '₁₀|decimal', '₁₆|hexadecimal', '1010₂', '1111₂', '10110₂', 'FF₁₆', 'A3₁₆', '7₈', '2⁰', '2¹', '2²', '2³', '2⁴', '2⁵', '2⁶', '2⁷', '2⁸', '2¹⁰', '2ⁿ', 'bit', 'byte', 'KB', 'MB', 'GB', 'TB', 'Kb', 'Mb', 'Gb', 'kbps', 'Mbps', 'Gbps', 'Hz', 'kHz', 'MHz', 'GHz'] },
      { t: 'Algorithms and flowcharts', s: ['→', '⟶', '⇄', '↻', '◇|decision', '▭|process', '▱|input or output', '⬭|start or end', '≤', '≥', '≠', '←|assign', ':=', 'O(1)', 'O(n)', 'O(n²)', 'O(log n)', 'mod', 'div', '√', 'Σ', '{ }', '[ ]', '( )', '" "', '//', '#', '&&', '||', '!'] },
      { t: 'Formulas', f: [
        ['Number of values in n bits', 'Number of values = 2ⁿ'],
        ['Number of colours', 'Number of colours = 2^(colour depth)'],
        ['Image file size', 'File size (bits) = width × height × colour depth'],
        ['Sound file size', 'File size (bits) = sample rate × bit depth × channels × time (s)'],
        ['Transfer time', 'Time = file size / transfer speed'],
        ['Bytes conversion', '1 KB = 1024 bytes;  1 MB = 1024 KB;  1 GB = 1024 MB;  1 TB = 1024 GB'],
        ['Bits to bytes', 'bytes = bits / 8'],
        ['Binary to decimal', '1011₂ = (1 × 2³) + (0 × 2²) + (1 × 2¹) + (1 × 2⁰) = 11₁₀'],
        ['Boolean laws', 'A + 0 = A;  A · 1 = A;  A + A̅ = 1;  A · A̅ = 0;  A + A = A;  A · A = A'],
        ["De Morgan's laws", '(A · B)′ = A′ + B′;  (A + B)′ = A′ · B′'],
        ['Bandwidth', 'Bandwidth = data / time'],
        ['Compression ratio', 'Compression ratio = original size / compressed size']
      ] }
    ] },

    { id: 'econ', name: 'Economics and Commerce', groups: [
      { t: 'Currency and symbols', s: ['₦|naira', 'k|kobo', '$', '€', '£', '¥', '¢', '%', '‰', 'Δ|change in', '∑', '→', '↑|increase', '↓|decrease', '⇑', '⇓', '≈', '±', '≥', '≤', 'P₁', 'P₂', 'Q₁', 'Q₂', 'Qd', 'Qs', 'Dr', 'Cr', 'GDP', 'GNP', 'CPI', 'VAT'] },
      { t: 'Formulas: economics', f: [
        ['Price elasticity of demand', 'PED = % change in quantity demanded / % change in price'],
        ['Price elasticity of supply', 'PES = % change in quantity supplied / % change in price'],
        ['Income elasticity of demand', 'YED = % change in quantity demanded / % change in income'],
        ['Cross elasticity of demand', 'XED = % change in Qd of A / % change in price of B'],
        ['Total revenue', 'TR = P × Q'],
        ['Average revenue', 'AR = TR / Q'],
        ['Marginal revenue', 'MR = ΔTR / ΔQ'],
        ['Total cost', 'TC = TFC + TVC'],
        ['Average cost', 'AC = TC / Q;  AFC = TFC / Q;  AVC = TVC / Q'],
        ['Marginal cost', 'MC = ΔTC / ΔQ'],
        ['Profit', 'Profit = TR − TC'],
        ['National income (expenditure)', 'GDP = C + I + G + (X − M)'],
        ['Per capita income', 'Per capita income = national income / population'],
        ['Average product', 'AP = TP / number of workers;  MP = ΔTP / ΔL'],
        ['Inflation rate', 'Inflation rate = (CPI₂ − CPI₁) / CPI₁ × 100'],
        ['Population growth', 'Growth rate = (births − deaths + net migration) / population × 100'],
        ['Equilibrium', 'Equilibrium: Qd = Qs']
      ] },
      { t: 'Formulas: commerce and accounts', f: [
        ['Gross profit', 'Gross profit = Sales − Cost of goods sold'],
        ['Net profit', 'Net profit = Gross profit − Expenses'],
        ['Cost of goods sold', 'COGS = Opening stock + Purchases − Closing stock'],
        ['Mark-up', 'Mark-up % = (Gross profit / Cost price) × 100'],
        ['Margin', 'Margin % = (Gross profit / Sales) × 100'],
        ['Rate of stock turnover', 'Rate of turnover = COGS / Average stock'],
        ['Average stock', 'Average stock = (Opening stock + Closing stock) / 2'],
        ['Working capital', 'Working capital = Current assets − Current liabilities'],
        ['Current ratio', 'Current ratio = Current assets : Current liabilities'],
        ['Accounting equation', 'Assets = Capital + Liabilities'],
        ['Return on capital', 'ROCE = (Net profit / Capital employed) × 100'],
        ['Trade discount', 'Net price = List price − Trade discount'],
        ['Simple interest', 'I = PRT / 100'],
        ['Depreciation (straight line)', 'Annual depreciation = (Cost − Residual value) / Useful life']
      ] }
    ] },

    { id: 'geo', name: 'Geography and General', groups: [
      { t: 'Direction and position', s: ['↑|north', '↗|north-east', '→|east', '↘|south-east', '↓|south', '↙|south-west', '←|west', '↖|north-west', '°N', '°S', '°E', '°W', '°', '′', '″', 'N', 'S', 'E', 'W', 'NE', 'NW', 'SE', 'SW', 'N 45° E', 'S 30° W', '045°', '135°', '225°', '315°', '⊕', '△|peak or trig point', '▲', '■', '●', '○', '✕', '≈', '∼'] },
      { t: 'General symbols', s: S('© ® ™ § ¶ † ‡ • ★ ☆ ✓ ✗ ☐ ☑ ± × ÷ ∞ ≈ ≠ ≤ ≥ → ← ↑ ↓ ↔ ⇒ ⇔ % ‰ ° ′ ″ № ℃ ℉ ½ ¼ ¾') },
      { t: 'Formulas', f: [
        ['Scale', 'Scale = map distance / ground distance'],
        ['Representative fraction', 'RF = 1 : 50 000'],
        ['Gradient', 'Gradient = vertical interval / horizontal distance'],
        ['Population density', 'Density = population / area (km²)'],
        ['Birth rate', 'Birth rate = (births / total population) × 1000'],
        ['Death rate', 'Death rate = (deaths / total population) × 1000'],
        ['Natural increase', 'Natural increase = birth rate − death rate'],
        ['Dependency ratio', 'Dependency ratio = (young + old) / working-age population × 100'],
        ['Time and longitude', '15° of longitude = 1 hour;  1° = 4 minutes'],
        ['Temperature range', 'Range = highest temperature − lowest temperature'],
        ['Mean temperature', 'Mean = (maximum + minimum) / 2'],
        ['Percentage', '% = (part / whole) × 100']
      ] }
    ] },

    { id: 'greek', name: 'Greek letters', groups: [
      { t: 'Small letters', s: S('α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ ς τ υ φ χ ψ ω') },
      { t: 'Capital letters', s: S('Α Β Γ Δ Ε Ζ Η Θ Ι Κ Λ Μ Ν Ξ Ο Π Ρ Σ Τ Υ Φ Χ Ψ Ω') }
    ] }
  ];

  /* ------------------------------------------------------------------ converters on selected text */
  const SUP = { '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '+': '⁺', '-': '⁻', '−': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
    a: 'ᵃ', b: 'ᵇ', c: 'ᶜ', d: 'ᵈ', e: 'ᵉ', f: 'ᶠ', g: 'ᵍ', h: 'ʰ', i: 'ⁱ', j: 'ʲ', k: 'ᵏ', l: 'ˡ', m: 'ᵐ', n: 'ⁿ', o: 'ᵒ', p: 'ᵖ', r: 'ʳ', s: 'ˢ', t: 'ᵗ', u: 'ᵘ', v: 'ᵛ', w: 'ʷ', x: 'ˣ', y: 'ʸ', z: 'ᶻ',
    A: 'ᴬ', B: 'ᴮ', D: 'ᴰ', E: 'ᴱ', G: 'ᴳ', H: 'ᴴ', I: 'ᴵ', J: 'ᴶ', K: 'ᴷ', L: 'ᴸ', M: 'ᴹ', N: 'ᴺ', O: 'ᴼ', P: 'ᴾ', R: 'ᴿ', T: 'ᵀ', U: 'ᵁ', V: 'ⱽ', W: 'ᵂ' };
  const SUB = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉', '+': '₊', '-': '₋', '−': '₋', '=': '₌', '(': '₍', ')': '₎',
    a: 'ₐ', e: 'ₑ', h: 'ₕ', i: 'ᵢ', j: 'ⱼ', k: 'ₖ', l: 'ₗ', m: 'ₘ', n: 'ₙ', o: 'ₒ', p: 'ₚ', r: 'ᵣ', s: 'ₛ', t: 'ₜ', u: 'ᵤ', v: 'ᵥ', x: 'ₓ' };
  const mapChars = (text, table) => Array.from(text).map(ch => table[ch] || ch).join('');
  const TOOLS = [
    { label: 'x²', title: 'Make the selected text a superscript (power)', fn: t => mapChars(t, SUP), name: 'superscript' },
    { label: 'x₂', title: 'Make the selected text a subscript', fn: t => mapChars(t, SUB), name: 'subscript' },
    { label: 'U̲', title: 'Underline the selected text', fn: t => Array.from(t).map(c => (c === ' ' || c === '\n') ? c : c + '\u0332').join(''), name: 'underline' },
    { label: 'ABC', title: 'Change the selected text to CAPITAL LETTERS', fn: t => t.toUpperCase(), name: 'capital letters' },
    { label: 'abc', title: 'Change the selected text to small letters', fn: t => t.toLowerCase(), name: 'small letters' }
  ];

  /* ------------------------------------------------------------------ building the panel */
  const FIELD = 'textarea[name=text], input[name^=opt_], input[name=answer_short]';
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const fieldName = f => {
    if (!f) return 'the question';
    if (f.name === 'text') return 'the question';
    if (f.name === 'answer_short') return 'the accepted answer';
    return 'option ' + f.name.replace('opt_', '').toUpperCase();
  };

  function build(form) {
    const host = form.querySelector('.sympal-host');
    if (!host || host.dataset.ready) return;
    host.dataset.ready = '1';
    let target = form.querySelector('textarea[name=text]');
    form.addEventListener('focusin', e => { if (e.target.matches(FIELD)) { target = e.target; where.textContent = 'Inserting into ' + fieldName(target); } });

    const box = el('details', 'sympal');
    const sum = el('summary', null, 'Symbols and formulas');
    sum.append(el('span', 'sympal-hint', 'Maths, Physics, Chemistry, English and more'));
    box.append(sum);
    const body = el('div', 'sympal-body');
    box.append(body);

    const tools = el('div', 'symtools');
    const where = el('span', 'symwhere', 'Inserting into the question');
    where.setAttribute('aria-live', 'polite');
    TOOLS.forEach(t => {
      const b = el('button', 'symbtn tool', t.label); b.type = 'button'; b.title = t.title; b.setAttribute('aria-label', t.title);
      b.addEventListener('click', () => {
        if (!target) return;
        const a = target.selectionStart, z = target.selectionEnd;
        if (a == null || a === z) { where.textContent = 'Select some text first, then press ' + t.name; return; }
        const out = t.fn(target.value.slice(a, z));
        target.setRangeText(out, a, z, 'select');
        target.dispatchEvent(new Event('input', { bubbles: true }));
        where.textContent = 'Changed to ' + t.name;
      });
      tools.append(b);
    });
    tools.append(where);
    body.append(tools);

    const tabs = el('div', 'symtabs'); tabs.setAttribute('role', 'tablist');
    const panel = el('div', 'sympanel'); panel.setAttribute('role', 'tabpanel');
    body.append(tabs, panel);

    function put(text) {
      if (!target) target = form.querySelector('textarea[name=text]');
      if (target.tagName === 'INPUT') text = text.replace(/\s*\n\s*/g, '  ');
      const a = target.selectionStart == null ? target.value.length : target.selectionStart;
      const z = target.selectionEnd == null ? a : target.selectionEnd;
      target.setRangeText(text, a, z, 'end');
      target.dispatchEvent(new Event('input', { bubbles: true }));
      target.focus();
      where.textContent = 'Inserted into ' + fieldName(target);
    }
    const symButton = (item) => {
      const k = item.lastIndexOf('|');
      const named = k > 0 && k < item.length - 1;
      const sym = named ? item.slice(0, k) : item, name = named ? item.slice(k + 1) : '';
      const b = el('button', 'symbtn', sym); b.type = 'button';
      b.title = name ? name + '  (' + sym.trim() + ')' : sym.trim();
      b.setAttribute('aria-label', name || sym);
      b.addEventListener('click', () => put(sym));
      return b;
    };
    function show(id) {
      const subj = DATA.find(d => d.id === id) || DATA[0];
      [...tabs.children].forEach(t => t.setAttribute('aria-selected', t.dataset.id === subj.id ? 'true' : 'false'));
      try { localStorage.setItem('rexx-sym-tab', subj.id); } catch (e) { /* ignore */ }
      panel.replaceChildren();
      subj.groups.forEach(g => {
        const grp = el('div', 'symgroup'); grp.append(el('h4', null, g.t));
        if (g.f) {
          const list = el('div', 'symformulas');
          g.f.forEach(([label, text]) => {
            const b = el('button', 'symbtn formula'); b.type = 'button'; b.title = 'Insert: ' + text.replace(/\n/g, ' ');
            b.append(el('span', 'fl', label), el('span', 'ft', text));
            b.addEventListener('click', () => put(text));
            list.append(b);
          });
          grp.append(list);
        } else {
          const grid = el('div', 'symgrid');
          g.s.forEach(i => grid.append(symButton(i)));
          if (g.s2) g.s2.forEach(i => grid.append(symButton(i)));
          grp.append(grid);
        }
        panel.append(grp);
      });
    }
    DATA.forEach((d, i) => {
      const t = el('button', 'symtab', d.name); t.type = 'button'; t.dataset.id = d.id;
      t.setAttribute('role', 'tab'); t.setAttribute('aria-selected', 'false');
      t.addEventListener('click', () => show(d.id));
      t.addEventListener('keydown', e => {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        const n = (i + (e.key === 'ArrowRight' ? 1 : DATA.length - 1)) % DATA.length;
        show(DATA[n].id); tabs.children[n].focus(); e.preventDefault();
      });
      tabs.append(t);
    });
    let first = 'maths';
    try { first = localStorage.getItem('rexx-sym-tab') || 'maths'; } catch (e) { /* ignore */ }
    show(first);

    /* keep the cursor and selection in the field while a symbol button is pressed */
    box.addEventListener('mousedown', e => { if (e.target.closest('button')) e.preventDefault(); });
    host.append(box);
  }

  document.querySelectorAll('.qform').forEach(build);
})();
