/* Rexx Hub - scientific calculator for the student exam screen.
   Self-contained: no eval(), no network, no storage. It floats above the exam, can be dragged,
   and keeps its keyboard events to itself so typing in it never picks an answer by accident. */
(() => {
  'use strict';
  const toggle = document.getElementById('calc-toggle');
  if (!toggle) return;

  /* ---------------- maths engine (recursive-descent parser) ---------------- */
  const MATH = 'Math Error', SYNTAX = 'Syntax Error';
  const NAMES = ['asin', 'acos', 'atan', 'sqrt', 'cbrt', 'sin', 'cos', 'tan', 'log', 'abs', 'ans', 'ln', 'pi', 'e'];
  const FUNCS = new Set(['asin', 'acos', 'atan', 'sqrt', 'cbrt', 'sin', 'cos', 'tan', 'log', 'abs', 'ln']);

  function tokenize(src) {
    const s = src
      .replace(/sin\u207b\u00b9/g, 'asin').replace(/cos\u207b\u00b9/g, 'acos').replace(/tan\u207b\u00b9/g, 'atan')
      .replace(/\u00d7/g, '*').replace(/\u00f7/g, '/').replace(/\u2212/g, '-')
      .replace(/\u03c0/g, 'pi').replace(/\u221a/g, 'sqrt').replace(/\u221b/g, 'cbrt')
      .replace(/\u00b2/g, '^2').replace(/\u00b3/g, '^3');
    const out = [];
    let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (c === ' ') { i++; continue; }
      const rest = s.slice(i);
      let m = /^(\d+\.?\d*|\.\d+)(E[+-]?\d+)?/.exec(rest);
      if (m) { out.push({ k: 'num', v: parseFloat(m[0]) }); i += m[0].length; continue; }
      const low = rest.toLowerCase();
      const name = NAMES.find(n => low.startsWith(n));
      if (name) { out.push({ k: 'id', v: name }); i += name.length; continue; }
      if ('+-*/^!%()'.includes(c)) { out.push({ k: 'op', v: c }); i++; continue; }
      throw new Error(SYNTAX);
    }
    return out;
  }

  function trig(name, x, deg, ctx) {
    ctx.trig = true;
    if (deg) {
      let a = x % 360; if (a < 0) a += 360;
      if (name === 'sin') {
        if (a === 0 || a === 180) return 0; if (a === 90) return 1; if (a === 270) return -1;
        if (a === 30 || a === 150) return 0.5; if (a === 210 || a === 330) return -0.5;
      } else if (name === 'cos') {
        if (a === 90 || a === 270) return 0; if (a === 0) return 1; if (a === 180) return -1;
        if (a === 60 || a === 300) return 0.5; if (a === 120 || a === 240) return -0.5;
      } else {
        if (a === 0 || a === 180) return 0; if (a === 90 || a === 270) throw new Error(MATH);
        if (a === 45 || a === 225) return 1; if (a === 135 || a === 315) return -1;
      }
      x = x * Math.PI / 180;
    }
    return Math[name](x);
  }

  function apply(name, x, ctx) {
    switch (name) {
      case 'sin': case 'cos': case 'tan': return trig(name, x, ctx.deg, ctx);
      case 'asin': case 'acos':
        if (x < -1 || x > 1) throw new Error(MATH);
        ctx.trig = true;
        return (Math[name](x)) * (ctx.deg ? 180 / Math.PI : 1);
      case 'atan': ctx.trig = true; return Math.atan(x) * (ctx.deg ? 180 / Math.PI : 1);
      case 'log': if (x <= 0) throw new Error(MATH); return Math.log10(x);
      case 'ln': if (x <= 0) throw new Error(MATH); return Math.log(x);
      case 'sqrt': if (x < 0) throw new Error(MATH); return Math.sqrt(x);
      case 'cbrt': return Math.cbrt(x);
      case 'abs': return Math.abs(x);
      default: throw new Error(SYNTAX);
    }
  }

  function fact(n) {
    if (!Number.isInteger(n) || n < 0 || n > 170) throw new Error(MATH);
    let r = 1; for (let i = 2; i <= n; i++) r *= i;
    return r;
  }

  // Returns a number, or null for an empty expression. Throws Error('Math Error' | 'Syntax Error').
  function evaluate(src, ctx) {
    const t = tokenize(src);
    if (!t.length) return null;
    let p = 0;
    const peek = () => t[p];
    const isOp = v => t[p] && t[p].k === 'op' && t[p].v === v;
    const startsPrimary = x => x && (x.k === 'num' || x.k === 'id' || (x.k === 'op' && x.v === '('));
    const close = () => { if (isOp(')')) p++; else if (peek()) throw new Error(SYNTAX); };

    function expr() {
      let v = term();
      while (isOp('+') || isOp('-')) { const o = t[p++].v; const r = term(); v = o === '+' ? v + r : v - r; }
      return v;
    }
    function term() {
      let v = implicit();
      for (;;) {
        if (isOp('*')) { p++; v *= implicit(); }
        else if (isOp('/')) { p++; const d = implicit(); if (d === 0) throw new Error(MATH); v /= d; }
        else break;
      }
      return v;
    }
    // 2\u03c0, 3(4+1), 2sin(30) bind tighter than * and /, like a school calculator
    function implicit() {
      let v = unary();
      while (startsPrimary(peek())) v *= power();
      return v;
    }
    function unary() {
      if (isOp('-')) { p++; return -unary(); }
      if (isOp('+')) { p++; return unary(); }
      return power();
    }
    function power() {
      const base = postfix();
      if (isOp('^')) { p++; return Math.pow(base, unary()); }
      return base;
    }
    function postfix() {
      let v = primary();
      while (isOp('!') || isOp('%')) { const o = t[p++].v; v = o === '!' ? fact(v) : v / 100; }
      return v;
    }
    function primary() {
      const x = t[p++];
      if (!x) throw new Error(SYNTAX);
      if (x.k === 'num') return x.v;
      if (x.k === 'op' && x.v === '(') { const v = expr(); close(); return v; }
      if (x.k === 'id') {
        if (x.v === 'pi') return Math.PI;
        if (x.v === 'e') return Math.E;
        if (x.v === 'ans') return ctx.ans;
        if (FUNCS.has(x.v)) {
          let a;
          if (isOp('(')) { p++; a = expr(); close(); } else a = unary();
          return apply(x.v, a, ctx);
        }
      }
      throw new Error(SYNTAX);
    }

    const v = expr();
    if (p < t.length) throw new Error(SYNTAX);
    if (!Number.isFinite(v)) throw new Error(MATH);
    if (ctx.trig && Math.abs(v) < 1e-12) return 0;      // sin(\u03c0) etc. shows 0, not 1.2E-16
    return v;
  }

  function fmt(v) {
    v = parseFloat(v.toPrecision(10));
    if (v === 0) return '0';
    const a = Math.abs(v);
    if (a >= 1e10 || a < 1e-9) return v.toExponential().replace('e+', 'E').replace('e-', 'E-');
    return String(v);
  }

  /* ---------------- interface ---------------- */
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };

  const panel = el('div', 'calc');
  panel.hidden = true;
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Scientific calculator');

  const head = el('div', 'calc-head');
  const title = el('span', '', 'Calculator');
  const mode = el('span', 'calc-mode', 'DEG');
  const closeBtn = el('button', 'calc-x', '\u2715'); closeBtn.type = 'button'; closeBtn.setAttribute('aria-label', 'Close calculator');
  head.append(title, mode, closeBtn);

  const screen = el('div', 'calc-screen');
  const input = el('input', 'calc-in');
  input.type = 'text'; input.autocomplete = 'off'; input.spellcheck = false;
  input.setAttribute('inputmode', 'none'); input.setAttribute('aria-label', 'Calculation');
  const res = el('div', 'calc-res', '0');
  res.setAttribute('aria-live', 'polite');
  screen.append(input, res);

  const keys = el('div', 'calc-keys');
  panel.append(head, screen, keys);
  document.body.append(panel);

  const ctx = { deg: true, ans: 0, trig: false };
  let justDone = false;

  function preview() {
    ctx.trig = false;
    try {
      const v = evaluate(input.value, ctx);
      res.classList.remove('err');
      res.textContent = v === null ? '0' : fmt(v);
    } catch (e) { res.classList.remove('err'); res.textContent = ''; }
  }

  function insert(text) {
    if (justDone) {                                   // after "=": an operator continues from Ans, anything else starts fresh
      input.value = /^[+\-\u00d7\u00f7^!%]/.test(text) || text.startsWith('^') ? 'Ans' : '';
      justDone = false;
    }
    const s = input.selectionStart ?? input.value.length, e = input.selectionEnd ?? s;
    input.value = input.value.slice(0, s) + text + input.value.slice(e);
    const pos = s + text.length;
    input.setSelectionRange(pos, pos);
    preview();
  }

  function del() {
    if (justDone) { justDone = false; }
    const s = input.selectionStart ?? input.value.length, e = input.selectionEnd ?? s;
    if (s !== e) { input.value = input.value.slice(0, s) + input.value.slice(e); input.setSelectionRange(s, s); preview(); return; }
    const before = input.value.slice(0, s);
    const m = /(sin\u207b\u00b9\(|cos\u207b\u00b9\(|tan\u207b\u00b9\(|sin\(|cos\(|tan\(|log\(|ln\(|\u221a\(|\u221b\(|Ans)$/.exec(before);
    const n = m ? m[0].length : 1;
    const from = Math.max(0, s - n);
    input.value = input.value.slice(0, from) + input.value.slice(s);
    input.setSelectionRange(from, from);
    preview();
  }

  function clearAll() { input.value = ''; justDone = false; res.classList.remove('err'); res.textContent = '0'; }

  function equals() {
    ctx.trig = false;
    try {
      const v = evaluate(input.value, ctx);
      if (v === null) return;
      ctx.ans = parseFloat(v.toPrecision(12));
      res.classList.remove('err');
      res.textContent = fmt(v);
      justDone = true;
    } catch (e) {
      res.classList.add('err');
      res.textContent = e.message === MATH ? MATH : SYNTAX;
    }
  }

  function setMode(deg) { ctx.deg = deg; mode.textContent = deg ? 'DEG' : 'RAD'; degKey.textContent = deg ? 'DEG' : 'RAD'; preview(); }

  // [label, type, value, extra class]
  const LAYOUT = [
    ['DEG', 'deg', '', 'fn'], ['(', 'ins', '(', 'fn'], [')', 'ins', ')', 'fn'], ['\u03c0', 'ins', '\u03c0', 'fn'], ['e', 'ins', 'e', 'fn'],
    ['sin', 'ins', 'sin(', 'fn'], ['cos', 'ins', 'cos(', 'fn'], ['tan', 'ins', 'tan(', 'fn'], ['log', 'ins', 'log(', 'fn'], ['ln', 'ins', 'ln(', 'fn'],
    ['sin\u207b\u00b9', 'ins', 'sin\u207b\u00b9(', 'fn'], ['cos\u207b\u00b9', 'ins', 'cos\u207b\u00b9(', 'fn'], ['tan\u207b\u00b9', 'ins', 'tan\u207b\u00b9(', 'fn'], ['10\u02e3', 'ins', '10^(', 'fn'], ['e\u02e3', 'ins', 'e^(', 'fn'],
    ['x\u00b2', 'ins', '^2', 'fn'], ['x\u02b8', 'ins', '^', 'fn'], ['\u221a', 'ins', '\u221a(', 'fn'], ['x\u207b\u00b9', 'ins', '^(-1)', 'fn'], ['n!', 'ins', '!', 'fn'],
    ['7', 'ins', '7', 'num'], ['8', 'ins', '8', 'num'], ['9', 'ins', '9', 'num'], ['DEL', 'del', '', 'ctl'], ['AC', 'ac', '', 'ctl'],
    ['4', 'ins', '4', 'num'], ['5', 'ins', '5', 'num'], ['6', 'ins', '6', 'num'], ['\u00d7', 'ins', '\u00d7', 'op'], ['\u00f7', 'ins', '\u00f7', 'op'],
    ['1', 'ins', '1', 'num'], ['2', 'ins', '2', 'num'], ['3', 'ins', '3', 'num'], ['+', 'ins', '+', 'op'], ['\u2212', 'ins', '\u2212', 'op'],
    ['0', 'ins', '0', 'num'], ['.', 'ins', '.', 'num'], ['EXP', 'ins', 'E', 'fn'], ['Ans', 'ins', 'Ans', 'fn'], ['=', 'eq', '', 'eq'],
  ];
  let degKey = null;
  LAYOUT.forEach(([label, type, value, cls]) => {
    const b = el('button', 'k ' + cls, label);
    b.type = 'button';
    b.addEventListener('mousedown', e => e.preventDefault());       // keep focus where it was (e.g. a short-answer box)
    b.addEventListener('click', () => {
      if (type === 'ins') insert(value);
      else if (type === 'del') del();
      else if (type === 'ac') clearAll();
      else if (type === 'eq') equals();
      else if (type === 'deg') setMode(!ctx.deg);
    });
    if (type === 'deg') degKey = b;
    keys.append(b);
  });

  /* typing on a keyboard into the display */
  input.addEventListener('input', () => {
    justDone = false;
    const clean = input.value.replace(/\*/g, '\u00d7').replace(/\//g, '\u00f7').replace(/[^0-9a-zA-Z.+\-^()!%,\u03c0eE\u221a\u221b\u00d7\u00f7\u2212\u00b2\u00b3\u207b\u00b9 ]/g, '');
    if (clean !== input.value) input.value = clean;
    preview();
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === '=') { e.preventDefault(); equals(); }
    else if (e.key === 'Escape') { e.preventDefault(); close(); }
  });
  // keep every key press inside the calculator away from the exam's A-E / arrow shortcuts
  panel.addEventListener('keydown', e => e.stopPropagation());

  /* open / close / drag */
  function place() {
    if (window.matchMedia('(max-width: 600px)').matches) return;     // phones: CSS docks it to the bottom
    if (panel.style.left) return;
    const w = panel.offsetWidth, h = panel.offsetHeight;
    panel.style.left = Math.max(8, window.innerWidth - w - 24) + 'px';
    panel.style.top = Math.max(8, window.innerHeight - h - 24) + 'px';
  }
  function open() { panel.hidden = false; toggle.setAttribute('aria-expanded', 'true'); place(); }
  function close() { panel.hidden = true; toggle.setAttribute('aria-expanded', 'false'); }
  toggle.addEventListener('click', () => (panel.hidden ? open() : close()));
  closeBtn.addEventListener('click', close);

  let drag = null;
  head.addEventListener('pointerdown', e => {
    if (e.target === closeBtn || window.matchMedia('(max-width: 600px)').matches) return;
    drag = { dx: e.clientX - panel.offsetLeft, dy: e.clientY - panel.offsetTop };
    head.setPointerCapture(e.pointerId);
    head.classList.add('drag');
  });
  head.addEventListener('pointermove', e => {
    if (!drag) return;
    const x = Math.min(Math.max(0, e.clientX - drag.dx), window.innerWidth - panel.offsetWidth);
    const y = Math.min(Math.max(0, e.clientY - drag.dy), window.innerHeight - panel.offsetHeight);
    panel.style.left = x + 'px'; panel.style.top = y + 'px';
  });
  const drop = () => { drag = null; head.classList.remove('drag'); };
  head.addEventListener('pointerup', drop);
  head.addEventListener('pointercancel', drop);
  window.addEventListener('resize', () => {           // keep it on screen if the window shrinks
    if (!panel.style.left) return;
    panel.style.left = Math.min(panel.offsetLeft, Math.max(0, window.innerWidth - panel.offsetWidth)) + 'px';
    panel.style.top = Math.min(panel.offsetTop, Math.max(0, window.innerHeight - panel.offsetHeight)) + 'px';
  });

  window.__rexxCalc = { evaluate, fmt };               // handy for testing; not used by the exam
})();
