document.querySelectorAll('.qform').forEach(form => {
  const select = form.querySelector('.qtype-select');
  const boxes = form.querySelectorAll('.qtype-box');
  const sync = () => boxes.forEach(b => { b.hidden = b.dataset.type !== select.value; });
  select.addEventListener('change', sync);
  sync();
});
