/* Rexx Hub - four-figure mathematical tables for the student exam screen.
   Logarithms, antilogarithms, sines, cosines and tangents with mean-difference columns.
   Every entry is computed here (no network, no storage). The panel floats above the exam,
   can be dragged, and keeps its keyboard events to itself like the calculator does. */
(() => {
  'use strict';
  const toggle = document.getElementById('tables-toggle');
  if (!toggle) return;

  const r4 = x => Math.round(x * 10000);
  const half = x => Math.floor(x + 0.5);                 // ordinary "round half up"
  const rad = d => d * Math.PI / 180;
  const lead0 = v => (v < 1 ? v.toFixed(4).slice(1) : v.toFixed(4));          // 0.0175 -> .0175, 1 -> 1.0000

  /* ---------- table builders: each returns {head, diffHead, rows:[{label, cells[], diffs[]}], note} ---------- */
  const cols10 = Array.from({ length: 10 }, (_, i) => i);
  const diff9 = Array.from({ length: 9 }, (_, i) => i + 1);

  function logTable() {
    const rows = [];
    for (let r = 10; r <= 99; r++) {
      const cells = cols10.map(c => String(r4(Math.log10((r * 10 + c) / 100))).padStart(4, '0'));
      const gap = r4(Math.log10((r + 1) / r)) / 10;      // average step per column along this row
      rows.push({ label: String(r), cells, diffs: diff9.map(k => String(half(k * gap / 10))) });
    }
    return { head: cols10.map(String), diffHead: diff9.map(String), rows,
      note: 'Find the first two digits down the side, the third digit across the top, and add the mean difference for the fourth digit. These are the mantissas (decimal part) only; the characteristic comes from the standard form.' };
  }

  function antilogTable() {
    const rows = [];
    for (let r = 0; r <= 99; r++) {
      const cells = cols10.map(c => String(half(Math.pow(10, r / 100 + c / 1000) * 1000)));
      const gap = (Math.pow(10, (r + 1) / 100) - Math.pow(10, r / 100)) * 1000 / 10;
      rows.push({ label: '.' + String(r).padStart(2, '0'), cells, diffs: diff9.map(k => String(half(k * gap / 10))) });
    }
    return { head: cols10.map(String), diffHead: diff9.map(String), rows,
      note: 'Look up the decimal part (mantissa) of the logarithm: first two decimals down the side, third across, and add the mean difference for the fourth. Place the decimal point using the characteristic.' };
  }

  const mins = Array.from({ length: 10 }, (_, i) => i * 6);
  const diff5 = [1, 2, 3, 4, 5];
  function trigTable(fn, label, sub) {
    const rows = [];
    for (let d = 0; d <= 89; d++) {
      const cells = mins.map(m => fn(rad(d + m / 60)));
      const next = fn(rad(d + 1)), here = fn(rad(d));
      const gap = (next - here) / 10;                     // average step per 6' column
      const diffs = diff5.map(k => {
        const v = k * gap / 6;                            // change for k minutes
        return (label === 'tan' && here >= 10) ? '-' : String(Math.abs(Math.round(v * 10000)));
      });
      const fmt = v => (label === 'tan' && v >= 1) ? Number(v.toPrecision(4)).toFixed(v >= 100 ? 1 : v >= 10 ? 2 : 3) : lead0(Math.round(v * 10000) / 10000);
      rows.push({ label: d + '\u00b0', cells: cells.map(fmt), diffs });
    }
    return { head: mins.map(m => m + '\u2032'), diffHead: diff5.map(k => k + '\u2032'), rows, note: sub };
  }

  const TABLES = [
    { id: 'log', name: 'Logarithms', build: logTable },
    { id: 'alog', name: 'Antilogarithms', build: antilogTable },
    { id: 'sin', name: 'Sines', build: () => trigTable(Math.sin, 'sin', 'Degrees down the side, minutes across (0\u2032 to 54\u2032). Add the mean difference for the extra 1\u2032 to 5\u2032.') },
    { id: 'cos', name: 'Cosines', build: () => trigTable(Math.cos, 'cos', 'Degrees down the side, minutes across. Cosine falls as the angle grows, so SUBTRACT the mean difference for the extra 1\u2032 to 5\u2032.') },
    { id: 'tan', name: 'Tangents', build: () => trigTable(Math.tan, 'tan', 'Degrees down the side, minutes across. Values of 1 and above are given to 4 significant figures; no mean differences are given for tangents of 10 and above.') },
  ];

  /* ---------- panel ---------- */
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };

  const panel = el('div', 'tbl'); panel.hidden = true;
  panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Mathematical tables');
  const head = el('div', 'tbl-head');
  const closeBtn = el('button', 'tbl-x', '\u2715'); closeBtn.type = 'button'; closeBtn.setAttribute('aria-label', 'Close tables');
  head.append(el('span', '', 'Mathematical tables'), closeBtn);
  const tabs = el('div', 'tbl-tabs');
  const wrap = el('div', 'tbl-wrap');
  const note = el('div', 'tbl-note');
  panel.append(head, tabs, wrap, note);
  document.body.append(panel);

  const cache = {};
  function show(id) {
    const def = TABLES.find(t => t.id === id);
    [...tabs.children].forEach(b => b.classList.toggle('on', b.dataset.id === id));
    if (!cache[id]) {
      const t = def.build();
      const table = el('table'), thead = el('thead'), hr = el('tr');
      hr.append(el('th', 'side', ''));
      t.head.forEach(h => hr.append(el('th', '', h)));
      t.diffHead.forEach((h, i) => hr.append(el('th', 'dif' + (i === 0 ? ' first' : ''), h)));
      thead.append(hr);
      const tb = el('tbody');
      t.rows.forEach(r => {
        const tr = el('tr');
        tr.append(el('th', 'side', r.label));
        r.cells.forEach(c => tr.append(el('td', '', c)));
        r.diffs.forEach((c, i) => tr.append(el('td', 'dif' + (i === 0 ? ' first' : ''), c)));
        tb.append(tr);
      });
      table.append(thead, tb);
      cache[id] = { table, note: t.note };
    }
    wrap.replaceChildren(cache[id].table);
    wrap.scrollTop = 0;
    note.textContent = cache[id].note;
  }
  TABLES.forEach(t => {
    const b = el('button', 'tbl-tab', t.name); b.type = 'button'; b.dataset.id = t.id;
    b.addEventListener('click', () => show(t.id));
    tabs.append(b);
  });

  panel.addEventListener('keydown', e => e.stopPropagation());   // never trigger the exam's A-E / arrow shortcuts

  /* open / close / drag */
  function place() {
    if (window.matchMedia('(max-width: 600px)').matches) return;   // phones: CSS docks it to the bottom
    if (panel.style.left) return;
    panel.style.left = '24px';
    panel.style.top = Math.max(8, 84) + 'px';
  }
  function open() {
    if (!wrap.firstChild) show('log');
    panel.hidden = false; toggle.setAttribute('aria-expanded', 'true'); place();
  }
  function close() { panel.hidden = true; toggle.setAttribute('aria-expanded', 'false'); }
  toggle.addEventListener('click', () => (panel.hidden ? open() : close()));
  closeBtn.addEventListener('click', close);

  let drag = null;
  head.addEventListener('pointerdown', e => {
    if (e.target === closeBtn || window.matchMedia('(max-width: 600px)').matches) return;
    drag = { dx: e.clientX - panel.offsetLeft, dy: e.clientY - panel.offsetTop };
    head.setPointerCapture(e.pointerId);
    head.classList.add('drag');
  });
  head.addEventListener('pointermove', e => {
    if (!drag) return;
    const x = Math.min(Math.max(0, e.clientX - drag.dx), window.innerWidth - panel.offsetWidth);
    const y = Math.min(Math.max(0, e.clientY - drag.dy), window.innerHeight - panel.offsetHeight);
    panel.style.left = x + 'px'; panel.style.top = y + 'px';
  });
  const drop = () => { drag = null; head.classList.remove('drag'); };
  head.addEventListener('pointerup', drop);
  head.addEventListener('pointercancel', drop);
  window.addEventListener('resize', () => {
    if (!panel.style.left) return;
    panel.style.left = Math.min(panel.offsetLeft, Math.max(0, window.innerWidth - panel.offsetWidth)) + 'px';
    panel.style.top = Math.min(panel.offsetTop, Math.max(0, window.innerHeight - panel.offsetHeight)) + 'px';
  });

  window.__rexxTables = TABLES.reduce((o, t) => (o[t.id] = t.build, o), {});   // for testing only
})();
